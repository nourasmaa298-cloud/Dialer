package app.glassdialer

import android.content.Context
import android.telecom.TelecomManager
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun Banner(title: String, desc: String, button: String, onClick: () -> Unit) {
    val c = LocalColors.current
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
            .glass(RoundedCornerShape(22.dp)).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = c.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text(desc, color = c.sub, fontSize = 13.sp)
        }
        Spacer(Modifier.width(12.dp))
        Box(
            Modifier.bounce(onClick = onClick).clip(RoundedCornerShape(16.dp)).background(c.accent)
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) { Text(button, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
    }
}

@Composable
fun RecentsList(
    calls: List<CallEntry>,
    top: @Composable () -> Unit,
    bottomPad: Dp,
    onCall: (String) -> Unit,
    onInfo: (CallEntry) -> Unit
) {
    val ctx = LocalContext.current
    val c = LocalColors.current
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = bottomPad)) {
        item { top() }
        if (calls.isEmpty()) item { EmptyState(stringResource(R.string.no_calls)) }
        items(calls, key = { it.id }) { e ->
            val missed = e.type == 3 || e.type == 5
            val base = e.name ?: if (e.number.isBlank()) stringResource(R.string.private_number) else prettyNumber(e.number)
            val title = if (e.count > 1) base + " (" + e.count + ")" else base
            val typeIcon = when (e.type) {
                1 -> Ic.received
                3, 5 -> Ic.missed
                else -> Ic.made
            }
            Row(
                Modifier.fillMaxWidth().tap { onCall(e.number) }.padding(horizontal = 20.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Avatar(e.name, e.photo, 46.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        title, color = if (missed) c.danger else c.text, fontSize = 17.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(typeIcon, null, Modifier.size(14.dp), tint = if (missed) c.danger else c.sub)
                        Spacer(Modifier.width(4.dp))
                        Text(
                            if (e.name != null) prettyNumber(e.number) else fmtDate(ctx, e.date),
                            color = c.sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                if (e.name != null) {
                    Text(fmtDate(ctx, e.date), color = c.sub, fontSize = 13.sp)
                }
                Box(Modifier.size(40.dp).tap { onInfo(e) }, contentAlignment = Alignment.Center) {
                    Icon(Ic.info, null, Modifier.size(22.dp), tint = c.sub)
                }
            }
        }
    }
}

@Composable
fun ContactsList(
    contacts: List<ContactEntry>,
    query: String,
    onQuery: (String) -> Unit,
    bottomPad: Dp,
    onCall: (String) -> Unit
) {
    val c = LocalColors.current
    val filtered = remember(contacts, query) {
        if (query.isBlank()) contacts
        else {
            val qd = query.filter { it.isDigit() }.ifEmpty { "\u0000" }
            contacts.filter { it.name.contains(query, ignoreCase = true) || it.number.filter { ch -> ch.isDigit() }.contains(qd) }
        }
    }
    Column(Modifier.fillMaxSize()) {
        BasicTextField(
            value = query, onValueChange = onQuery, singleLine = true,
            textStyle = TextStyle(color = c.text, fontSize = 16.sp),
            cursorBrush = SolidColor(c.accent),
            decorationBox = { inner ->
                Row(Modifier.fillMaxHeight(), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Ic.search, null, Modifier.size(20.dp), tint = c.sub)
                    Spacer(Modifier.width(10.dp))
                    Box(Modifier.weight(1f)) {
                        if (query.isEmpty()) Text(stringResource(R.string.search_contacts), color = c.sub, fontSize = 16.sp)
                        inner()
                    }
                }
            },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp).height(52.dp)
                .glass(RoundedCornerShape(26.dp)).padding(horizontal = 16.dp)
        )
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = bottomPad)) {
            if (filtered.isEmpty()) item { EmptyState(stringResource(R.string.no_contacts)) }
            itemsIndexed(filtered, key = { _, e -> e.id.toString() + ":" + Repo.norm(e.number) }) { i, e ->
                val letter = e.name.firstOrNull { it.isLetter() }?.uppercaseChar() ?: '#'
                val prev = if (i > 0) filtered[i - 1].name.firstOrNull { it.isLetter() }?.uppercaseChar() ?: '#' else null
                Column(Modifier.fillMaxWidth()) {
                    if (prev != letter) {
                        Text(
                            letter.toString(), color = c.accent, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(start = 24.dp, top = 12.dp, bottom = 2.dp)
                        )
                    }
                    Row(
                        Modifier.fillMaxWidth().tap { onCall(e.number) }.padding(horizontal = 20.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Avatar(e.name, e.photo, 44.dp)
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text(e.name, color = c.text, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(prettyNumber(e.number), color = c.sub, fontSize = 13.sp, maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}

private class Act(val label: String, val icon: ImageVector, val color: Color, val run: () -> Unit)

@Composable
fun DetailScreen(
    number: String,
    name: String?,
    photo: String?,
    history: List<CallEntry>,
    onBack: () -> Unit,
    onCall: () -> Unit,
    onVideo: () -> Unit,
    onDeleted: () -> Unit
) {
    val ctx = LocalContext.current
    val c = LocalColors.current
    val acts = ArrayList<Act>()
    acts.add(Act(stringResource(R.string.call), Ic.call, c.link, onCall))
    if (name == null) {
        acts.add(Act(stringResource(R.string.new_contact), Ic.personAdd, c.link) { safeStart(ctx, newContactIntent(number)) })
        acts.add(Act(stringResource(R.string.add_to_contacts), Ic.add, c.link) { safeStart(ctx, addToContactIntent(number)) })
    }
    acts.add(Act(stringResource(R.string.video_call), Ic.videocam, c.link, onVideo))
    acts.add(Act(stringResource(R.string.send_message), Ic.message, c.link) { safeStart(ctx, smsIntent(number)) })
    acts.add(Act(stringResource(R.string.delete_entry), Ic.delete, c.danger) {
        Repo.deleteNumber(ctx, number)
        onDeleted()
    })

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        TopBar(stringResource(R.string.recents) + "  |  " + prettyNumber(number), onBack)
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 32.dp)) {
            item {
                Column(Modifier.fillMaxWidth().padding(vertical = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Avatar(name, photo, 96.dp)
                    Spacer(Modifier.height(12.dp))
                    Text(name ?: prettyNumber(number), color = c.text, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
                    if (name != null) Text(prettyNumber(number), color = c.sub, fontSize = 15.sp)
                }
            }
            item {
                Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(24.dp))) {
                    acts.forEach { a ->
                        Row(
                            Modifier.fillMaxWidth().tap { a.run() }.padding(horizontal = 18.dp, vertical = 15.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(a.icon, null, Modifier.size(22.dp), tint = a.color)
                            Spacer(Modifier.width(14.dp))
                            Text(a.label, color = a.color, fontSize = 17.sp)
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(16.dp)) }
            items(history, key = { it.id }) { e ->
                val ctx2 = LocalContext.current
                Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    val missed = e.type == 3 || e.type == 5
                    Icon(
                        when (e.type) {
                            1 -> Ic.received
                            3, 5 -> Ic.missed
                            else -> Ic.made
                        },
                        null, Modifier.size(18.dp), tint = if (missed) c.danger else c.sub
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(fmtDate(ctx2, e.date), color = c.text, fontSize = 15.sp, modifier = Modifier.weight(1f))
                    if (e.duration > 0) Text(fmtTime(e.duration), color = c.sub, fontSize = 14.sp)
                }
            }
        }
    }
}

@Composable
fun <T> ChipGroup(options: List<Pair<String, T>>, selected: T, perRow: Int = 2, onSelect: (T) -> Unit) {
    val c = LocalColors.current
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        options.chunked(perRow).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { (label, v) ->
                    val sel = v == selected
                    Box(
                        Modifier.weight(1f).height(44.dp).bounce { onSelect(v) }
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (sel) c.accent else c.text.copy(alpha = 0.08f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            label, color = if (sel) Color.White else c.text, fontSize = 14.sp,
                            fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                repeat(perRow - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
private fun SettingsCard(title: String, content: @Composable () -> Unit) {
    val c = LocalColors.current
    Column(
        Modifier.fillMaxWidth().glass(RoundedCornerShape(24.dp)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(title, color = c.sub, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        content()
    }
}

@Composable
private fun SubLabel(text: String) {
    Text(text, color = LocalColors.current.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
}

@Composable
private fun SwitchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val c = LocalColors.current
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = c.text, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = c.accent, checkedThumbColor = Color.White)
        )
    }
}

@Composable
fun SettingsScreen(sims: List<SimAccount>, isDefault: Boolean, onRequestDefault: () -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val c = LocalColors.current
    val version = remember {
        runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "1.0"
    }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        TopBar(stringResource(R.string.settings), onBack)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            SettingsCard(stringResource(R.string.default_dialer)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        stringResource(if (isDefault) R.string.status_yes else R.string.status_no),
                        color = if (isDefault) c.accent else c.sub, fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)
                    )
                    if (!isDefault) {
                        Box(
                            Modifier.bounce(onClick = onRequestDefault).clip(RoundedCornerShape(16.dp))
                                .background(c.accent).padding(horizontal = 16.dp, vertical = 10.dp)
                        ) { Text(stringResource(R.string.set_default), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
                    }
                }
            }

            SettingsCard(stringResource(R.string.appearance)) {
                SubLabel(stringResource(R.string.theme_mode))
                ChipGroup(
                    listOf(
                        stringResource(R.string.mode_system) to ThemeMode.SYSTEM,
                        stringResource(R.string.mode_light) to ThemeMode.LIGHT,
                        stringResource(R.string.mode_dark) to ThemeMode.DARK
                    ),
                    Prefs.themeMode, 3
                ) { Prefs.updateThemeMode(it) }
                SubLabel(stringResource(R.string.style))
                ChipGroup(
                    listOf(
                        stringResource(R.string.style_solid) to GlassStyle.SOLID,
                        stringResource(R.string.style_glass) to GlassStyle.GLASS,
                        stringResource(R.string.style_frosted) to GlassStyle.FROSTED,
                        stringResource(R.string.style_liquid) to GlassStyle.LIQUID
                    ),
                    Prefs.glass, 2
                ) { Prefs.updateGlass(it) }
                SubLabel(stringResource(R.string.accent))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Accent.values().forEach { a ->
                        Box(
                            Modifier.size(42.dp).bounce { Prefs.updateAccent(a) }.clip(CircleShape).background(Color(a.argb)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (Prefs.accent == a) Icon(Ic.check, null, Modifier.size(22.dp), tint = Color.White)
                        }
                    }
                }
            }

            SettingsCard(stringResource(R.string.language)) {
                ChipGroup(
                    listOf(
                        stringResource(R.string.lang_system) to "",
                        "English" to "en",
                        "العربية" to "ar",
                        "Türkçe" to "tr"
                    ),
                    Prefs.lang, 2
                ) { Prefs.updateLang(it) }
            }

            SettingsCard(stringResource(R.string.calls_section)) {
                SwitchRow(stringResource(R.string.dtmf_tones), Prefs.tones) { Prefs.updateTones(it) }
                SwitchRow(stringResource(R.string.haptics), Prefs.haptics) { Prefs.updateHaptics(it) }
                if (sims.size > 1) {
                    SubLabel(stringResource(R.string.default_sim))
                    ChipGroup(
                        listOf(
                            stringResource(R.string.sim_ask) to -1,
                            sims[0].label to 0,
                            sims[1].label to 1
                        ),
                        Prefs.defaultSim, 3
                    ) { Prefs.updateDefaultSim(it) }
                }
                Text(
                    stringResource(R.string.blocked_numbers), color = c.link, fontSize = 16.sp,
                    modifier = Modifier.fillMaxWidth().tap {
                        try {
                            val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
                            safeStart(ctx, tm.createManageBlockedNumbersIntent())
                        } catch (_: Throwable) {
                        }
                    }.padding(vertical = 6.dp)
                )
            }

            SettingsCard(stringResource(R.string.about)) {
                Text(stringResource(R.string.app_name), color = c.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Text(stringResource(R.string.version, version), color = c.sub, fontSize = 14.sp)
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun NavItem(icon: ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    val c = LocalColors.current
    Column(
        Modifier.width(92.dp).bounce(onClick = onClick).clip(RoundedCornerShape(24.dp))
            .background(if (selected) c.text.copy(alpha = 0.13f) else Color.Transparent)
            .padding(vertical = 7.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, Modifier.size(22.dp), tint = if (selected) c.text else c.sub)
        Text(label, color = if (selected) c.text else c.sub, fontSize = 11.sp, maxLines = 1, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun BottomNav(tab: Int, onTab: (Int) -> Unit, padOpen: Boolean, onPad: () -> Unit) {
    val c = LocalColors.current
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.glass(RoundedCornerShape(32.dp)).padding(6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            NavItem(Ic.history, stringResource(R.string.recents), tab == 0) { onTab(0) }
            NavItem(Ic.contacts, stringResource(R.string.contacts), tab == 1) { onTab(1) }
        }
        Box(
            Modifier.size(60.dp).bounce(onClick = onPad).then(
                if (padOpen) Modifier.glass(CircleShape) else Modifier.clip(CircleShape).background(c.accent)
            ),
            contentAlignment = Alignment.Center
        ) {
            Icon(Ic.dialpad, null, Modifier.size(26.dp), tint = if (padOpen) c.text else Color.White)
        }
    }
}
