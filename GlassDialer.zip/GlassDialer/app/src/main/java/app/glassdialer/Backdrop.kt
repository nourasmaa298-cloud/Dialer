package app.glassdialer

import android.graphics.RuntimeShader
import android.graphics.Shader
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.RenderEffect
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import kotlin.math.min

/** A recorded picture of "everything behind the glass". */
class BackdropSource(val layer: GraphicsLayer)

val LocalBackdrop = staticCompositionLocalOf<BackdropSource?> { null }

/** Marks this node (and its content) as a backdrop that glass panels can blur. Panels must NOT be inside it. */
fun Modifier.backdropSource(layer: GraphicsLayer): Modifier = this.drawWithContent {
    layer.record { this@drawWithContent.drawContent() }
    drawLayer(layer)
}

@Composable
internal fun Modifier.glassBlur(src: BackdropSource, shape: Shape, liquid: Boolean): Modifier {
    val c = LocalColors.current
    val density = LocalDensity.current
    val layer = rememberGraphicsLayer()
    val pos = remember { mutableStateOf(Offset.Zero) }
    val fx: Any? = remember(liquid) {
        if (liquid && Build.VERSION.SDK_INT >= 33) LiquidFx.create() else null
    }
    val t = rememberInfiniteTransition(label = "glassfx")
    val phase = t.animateFloat(
        initialValue = 0f, targetValue = 6.2831855f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Restart),
        label = "phase"
    )
    val blurPx = with(density) { (if (liquid) 14.dp else 24.dp).toPx() }
    val lensPx = with(density) { 16.dp.toPx() }
    val tintTop = if (c.dark) Color.White.copy(alpha = if (liquid) 0.14f else 0.10f)
    else Color.White.copy(alpha = if (liquid) 0.50f else 0.38f)
    val tintBottom = if (c.dark) Color.White.copy(alpha = if (liquid) 0.04f else 0.07f)
    else Color.White.copy(alpha = if (liquid) 0.20f else 0.30f)

    return this
        .onGloballyPositioned { pos.value = it.positionInRoot() }
        .clip(shape)
        .drawBehind {
            val p = pos.value
            layer.record { translate(-p.x, -p.y) { drawLayer(src.layer) } }
            var effect: RenderEffect? = null
            if (fx != null) {
                val outline = shape.createOutline(size, layoutDirection, this)
                val radius = if (outline is Outline.Rounded) {
                    outline.roundRect.topLeftCornerRadius.x
                } else min(size.width, size.height) / 2f
                effect = LiquidFx.effect(fx, size.width, size.height, radius, lensPx, phase.value, blurPx)
            }
            layer.renderEffect = effect ?: BlurEffect(blurPx, blurPx, TileMode.Clamp)
            drawLayer(layer)
        }
        .background(Brush.verticalGradient(listOf(tintTop, tintBottom)))
        .drawBehind {
            if (liquid) {
                val cx = size.width * (0.15f + 0.7f * (0.5f + 0.5f * kotlin.math.sin(phase.value)))
                blob(Color.White.copy(alpha = if (c.dark) 0.26f else 0.55f), cx, 0f, size.maxDimension * 0.7f)
                blob(c.accent.copy(alpha = 0.20f), size.width - cx, size.height, size.maxDimension * 0.55f)
            }
        }
        .border(
            if (liquid) 1.3.dp else 1.dp,
            Brush.linearGradient(
                listOf(
                    Color.White.copy(alpha = if (liquid) 0.9f else 0.45f),
                    Color.White.copy(alpha = 0.06f),
                    Color.White.copy(alpha = if (liquid) 0.5f else 0.22f)
                )
            ),
            shape
        )
}

/** Lens-like refraction + chromatic dispersion + a slow watery wobble (AGSL, Android 13+). */
@RequiresApi(33)
internal object LiquidFx {
    private const val SRC = """
uniform shader content;
uniform float2 size;
uniform float radius;
uniform float strength;
uniform float phase;

float sdRoundRect(float2 p, float2 b, float r) {
    float2 q = abs(p) - b + float2(r, r);
    return min(max(q.x, q.y), 0.0) + length(max(q, float2(0.0, 0.0))) - r;
}

half4 main(float2 coord) {
    float2 hs = size * 0.5;
    float2 p = coord - hs;
    float d = sdRoundRect(p, hs, radius);
    float2 g = float2(
        sdRoundRect(p + float2(1.0, 0.0), hs, radius) - sdRoundRect(p - float2(1.0, 0.0), hs, radius),
        sdRoundRect(p + float2(0.0, 1.0), hs, radius) - sdRoundRect(p - float2(0.0, 1.0), hs, radius));
    float2 n = g / max(length(g), 0.0001);
    float band = max(min(size.x, size.y) * 0.32, 8.0);
    float t = clamp(-d / band, 0.0, 1.0);
    float bend = pow(1.0 - t, 2.0);
    float2 flow = float2(sin(coord.y * 0.05 + phase), cos(coord.x * 0.05 + phase)) * 1.5;
    float2 uv0 = coord - n * bend * strength + flow * (0.3 + bend);
    float2 lo = float2(0.5, 0.5);
    float2 hi = size - float2(0.5, 0.5);
    half4 c = content.eval(clamp(uv0, lo, hi));
    half4 cr = content.eval(clamp(uv0 - n * bend * strength * 0.10, lo, hi));
    half4 cb = content.eval(clamp(uv0 + n * bend * strength * 0.10, lo, hi));
    return half4(cr.r, c.g, cb.b, c.a);
}
"""

    fun create(): Any? = try {
        RuntimeShader(SRC)
    } catch (_: Throwable) {
        null
    }

    fun effect(
        shader: Any, w: Float, h: Float, radius: Float, strength: Float, phase: Float, blur: Float
    ): RenderEffect? = try {
        val s = shader as RuntimeShader
        s.setFloatUniform("size", w, h)
        s.setFloatUniform("radius", radius)
        s.setFloatUniform("strength", strength)
        s.setFloatUniform("phase", phase)
        val lens = android.graphics.RenderEffect.createRuntimeShaderEffect(s, "content")
        val soft = android.graphics.RenderEffect.createBlurEffect(blur, blur, Shader.TileMode.CLAMP)
        android.graphics.RenderEffect.createChainEffect(lens, soft).asComposeRenderEffect()
    } catch (_: Throwable) {
        null
    }
}
