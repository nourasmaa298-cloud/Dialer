package app.glassdialer

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import app.glassdialer.call.CallManager

class MainActivity : AppCompatActivity() {

    private var dialRequest by mutableStateOf<String?>(null)
    private var tabRequest by mutableStateOf<Int?>(null)
    private var tick by mutableIntStateOf(0)
    private var permTick by mutableIntStateOf(0)

    private val roleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { permTick++ }
    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permTick++ }
    private val imageLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {
                }
                Prefs.updateBgImage(uri.toString())
                Prefs.updateAppBg(AppBg.IMAGE)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (savedInstanceState == null) handleIntent(intent)
        addOnNewIntentListener { handleIntent(it) }
        setContent { AppTheme { AppBackground { Root() } } }
    }

    override fun onResume() {
        super.onResume()
        tick++
        permTick++
    }

    private fun handleIntent(i: Intent?) {
        if (i == null) return
        if (i.hasExtra("tab")) tabRequest = i.getIntExtra("tab", 0)
        if (i.action == Intent.ACTION_DIAL || i.action == Intent.ACTION_VIEW) {
            val d = i.data
            dialRequest = if (d != null && d.scheme == "tel") Uri.decode(d.schemeSpecificPart ?: "") else ""
        }
    }

    private fun perms(): Array<String> {
        val l = mutableListOf(
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.WRITE_CALL_LOG
        )
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        return l.toTypedArray()
    }

    private fun allGranted(): Boolean = perms().all { has(it) }

    private fun requestDefault() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val rm = getSystemService(RoleManager::class.java)
                if (rm.isRoleAvailable(RoleManager.ROLE_DIALER) && !rm.isRoleHeld(RoleManager.ROLE_DIALER)) {
                    roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER))
                }
            } else {
                roleLauncher.launch(
                    Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
                        .putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName)
                )
            }
        } catch (_: Exception) {
        }
    }

    @Composable
    private fun Root() {
        val ctx = this@MainActivity
        val c = LocalColors.current

        var tab by rememberSaveable { mutableStateOf(0) }
        var showPad by rememberSaveable { mutableStateOf(false) }
        var number by rememberSaveable { mutableStateOf("") }
        var inSettings by rememberSaveable { mutableStateOf(false) }
        var detail by rememberSaveable { mutableStateOf<String?>(null) }
        var query by rememberSaveable { mutableStateOf("") }
        var pending by remember { mutableStateOf<String?>(null) }

        val pt = permTick
        val tk = tick
        val granted = remember(pt) { allGranted() }
        val isDefault = remember(pt) { isDefaultDialer(ctx) }
        val sims = remember(pt) { simAccounts(ctx) }
        val contacts by produceState(emptyList<ContactEntry>(), tk, pt) { value = Repo.contacts(ctx) }
        val byNum = remember(contacts) { contacts.associateBy { Repo.norm(it.number) } }
        val calls by produceState(emptyList<CallEntry>(), tk, pt, byNum) { value = Repo.calls(ctx, byNum) }
        val live by CallManager.calls.collectAsState()

        val dr = dialRequest
        LaunchedEffect(dr) {
            if (dr != null) {
                number = dr
                showPad = true
                inSettings = false
                detail = null
                dialRequest = null
            }
        }
        val tr = tabRequest
        LaunchedEffect(tr) {
            if (tr != null) {
                tab = tr
                inSettings = false
                detail = null
                tabRequest = null
            }
        }
        LaunchedEffect(Unit) { if (!allGranted()) permLauncher.launch(perms()) }

        fun startCall(num: String, handle: PhoneAccountHandle?) {
            if (!ctx.has(Manifest.permission.CALL_PHONE)) {
                permLauncher.launch(perms())
                return
            }
            placeCall(ctx, num, handle)
        }

        fun dial(num: String) {
            if (num.isBlank()) return
            when {
                sims.size < 2 -> startCall(num, sims.firstOrNull()?.handle)
                Prefs.defaultSim in sims.indices -> startCall(num, sims[Prefs.defaultSim].handle)
                else -> pending = num
            }
        }

        val suggestion = remember(number, contacts) {
            val d = number.filter { it.isDigit() }
            if (d.length < 3) null
            else contacts.firstOrNull { it.number.filter { ch -> ch.isDigit() }.contains(d) }?.name
        }

        BackHandler(enabled = inSettings || detail != null || showPad) {
            when {
                detail != null -> detail = null
                inSettings -> inSettings = false
                else -> showPad = false
            }
        }

        val screen = if (inSettings) 1 else if (detail != null) 2 else 0
        AnimatedContent(
            targetState = screen,
            transitionSpec = {
                if (!Prefs.motion) {
                    EnterTransition.None togetherWith ExitTransition.None
                } else {
                    (fadeIn(tween(260)) + scaleIn(tween(300), initialScale = 0.96f)) togetherWith
                        fadeOut(tween(180))
                }
            },
            label = "screen"
        ) { s ->
            when (s) {
                1 -> SettingsScreen(
                    sims, isDefault,
                    { requestDefault() },
                    { imageLauncher.launch(arrayOf("image/*")) },
                    { inSettings = false }
                )

                2 -> {
                    val dn = detail ?: ""
                    val hist = calls.filter { it.number == dn }
                    val first = hist.firstOrNull()
                    DetailScreen(
                        number = dn, name = first?.name, photo = first?.photo, history = hist,
                        onBack = { detail = null },
                        onCall = { dial(dn) },
                        onVideo = { placeCall(ctx, dn, null, true) },
                        onDeleted = {
                            tick++
                            detail = null
                        }
                    )
                }

                else -> Box(Modifier.fillMaxSize()) {
                    Column(Modifier.fillMaxSize().statusBarsPadding()) {
                        AnimatedContent(
                            targetState = tab,
                            transitionSpec = {
                                fadeIn(tween(220)) togetherWith fadeOut(tween(160))
                            },
                            label = "title"
                        ) { t ->
                            TopBar(stringResource(if (t == 0) R.string.recents else R.string.contacts)) {
                                Box(Modifier.size(44.dp).tap { inSettings = true }, contentAlignment = Alignment.Center) {
                                    Icon(Ic.settings, null, tint = c.sub)
                                }
                            }
                        }
                        if (live.isNotEmpty()) {
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
                                    .tap { safeStart(ctx, Intent(ctx, InCallActivity::class.java)) }
                                    .clip(RoundedCornerShape(18.dp)).background(c.accent).padding(vertical = 9.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Ic.call, null, Modifier.size(16.dp), tint = Color.White)
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    stringResource(R.string.return_to_call), color = Color.White,
                                    fontSize = 14.sp, fontWeight = FontWeight.Medium
                                )
                            }
                        }
                        AnimatedContent(
                            targetState = tab,
                            modifier = Modifier.weight(1f),
                            transitionSpec = {
                                if (!Prefs.motion) {
                                    EnterTransition.None togetherWith ExitTransition.None
                                } else if (targetState > initialState) {
                                    (slideInHorizontally(tween(320)) { it / 3 } + fadeIn(tween(280))) togetherWith
                                        (slideOutHorizontally(tween(320)) { -it / 3 } + fadeOut(tween(200)))
                                } else {
                                    (slideInHorizontally(tween(320)) { -it / 3 } + fadeIn(tween(280))) togetherWith
                                        (slideOutHorizontally(tween(320)) { it / 3 } + fadeOut(tween(200)))
                                }
                            },
                            label = "tabs"
                        ) { t ->
                            if (t == 0) {
                                RecentsList(
                                    calls = calls,
                                    top = {
                                        Column {
                                            if (!granted) {
                                                Banner(
                                                    stringResource(R.string.perms_title), stringResource(R.string.perms_desc),
                                                    stringResource(R.string.grant)
                                                ) { permLauncher.launch(perms()) }
                                            }
                                            if (!isDefault) {
                                                Banner(
                                                    stringResource(R.string.default_title), stringResource(R.string.default_desc),
                                                    stringResource(R.string.set_default)
                                                ) { requestDefault() }
                                            }
                                        }
                                    },
                                    bottomPad = 130.dp,
                                    onCall = { dial(it) },
                                    onInfo = { detail = it.number }
                                )
                            } else {
                                ContactsList(contacts, query, { query = it }, 130.dp) { dial(it) }
                            }
                        }
                    }

                    Column(
                        Modifier.align(Alignment.BottomCenter).navigationBarsPadding()
                            .padding(horizontal = 16.dp).padding(bottom = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        AnimatedVisibility(
                            visible = showPad,
                            enter = fadeIn(tween(180)) +
                                slideInVertically(spring(stiffness = Spring.StiffnessMediumLow)) { it / 3 } +
                                scaleIn(initialScale = 0.92f),
                            exit = fadeOut(tween(140)) +
                                slideOutVertically(tween(180)) { it / 3 } +
                                scaleOut(targetScale = 0.92f)
                        ) {
                            Column {
                                DialPadCard(
                                    number = number,
                                    suggestion = suggestion,
                                    sims = sims,
                                    onKey = { ch -> if (number.length < 30) number += ch },
                                    onDelete = { number = number.dropLast(1) },
                                    onClear = { number = "" },
                                    onCall = { handle -> if (number.isNotEmpty()) startCall(number, handle) }
                                )
                                Spacer(Modifier.height(12.dp))
                            }
                        }
                        BottomNav(tab, { tab = it }, showPad) { showPad = !showPad }
                    }
                }
            }
        }

        val pn = pending
        if (pn != null) {
            AlertDialog(
                onDismissRequest = { pending = null },
                containerColor = c.surfaceHigh,
                title = { Text(stringResource(R.string.choose_sim), color = c.text) },
                text = {
                    Column {
                        sims.forEach { s ->
                            Text(
                                s.label, color = c.text, fontSize = 17.sp,
                                modifier = Modifier.fillMaxWidth().tap {
                                    startCall(pn, s.handle)
                                    pending = null
                                }.padding(vertical = 14.dp)
                            )
                        }
                    }
                },
                confirmButton = {}
            )
        }
    }
}
