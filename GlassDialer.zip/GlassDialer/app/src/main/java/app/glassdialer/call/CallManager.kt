package app.glassdialer.call

import android.os.Build
import android.os.Handler
import android.os.Looper
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import android.telecom.VideoProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import app.glassdialer.R
import java.util.concurrent.CopyOnWriteArrayList

object CallManager {
    data class Info(val call: Call, val state: Int, val number: String, val connectMs: Long, val name: String?, val props: Int)

    private val list = CopyOnWriteArrayList<Call>()
    private val callbacks = HashMap<Call, Call.Callback>()
    private val _calls = MutableStateFlow<List<Info>>(emptyList())
    val calls: StateFlow<List<Info>> = _calls

    val muted = MutableStateFlow(false)
    val route = MutableStateFlow(CallAudioState.ROUTE_EARPIECE)
    val routeMask = MutableStateFlow(0)

    @Volatile
    var service: InCallService? = null

    @Suppress("DEPRECATION")
    fun stateOf(c: Call): Int = if (Build.VERSION.SDK_INT >= 31) c.details.state else c.state

    private fun numberOf(c: Call): String = c.details?.handle?.schemeSpecificPart ?: ""

    fun add(call: Call) {
        val cb = object : Call.Callback() {
            override fun onStateChanged(call: Call, state: Int) = publish()
            override fun onDetailsChanged(call: Call, details: Call.Details) = publish()
        }
        call.registerCallback(cb)
        callbacks[call] = cb
        list.add(call)
        publish()
    }

    fun remove(call: Call) {
        callbacks.remove(call)?.let { call.unregisterCallback(it) }
        list.remove(call)
        publish()
    }

    private fun publish() {
        _calls.value = list.map {
            Info(it, stateOf(it), numberOf(it), it.details?.connectTimeMillis ?: 0L, it.details?.callerDisplayName, it.details?.callProperties ?: 0)
        }
        val svc = service ?: return
        try {
            if (list.none { stateOf(it) == Call.STATE_RINGING }) Notifs.cancel(svc)
            val live = list.firstOrNull {
                val st = stateOf(it)
                st != Call.STATE_RINGING && st != Call.STATE_DISCONNECTED
            }
            if (live != null) {
                val n = numberOf(live)
                val nm = live.details?.callerDisplayName
                Notifs.showOngoing(
                    svc,
                    if (!nm.isNullOrBlank()) nm else if (n.isNotBlank()) n else svc.getString(R.string.unknown)
                )
            } else {
                Notifs.cancelOngoing(svc)
            }
        } catch (_: Throwable) {
        }
    }

    fun answer(c: Call) = c.answer(VideoProfile.STATE_AUDIO_ONLY)
    fun reject(c: Call) = c.reject(false, null)
    fun hangup(c: Call) = c.disconnect()
    fun hold(c: Call, hold: Boolean) { if (hold) c.hold() else c.unhold() }
    fun setMuted(m: Boolean) { service?.setMuted(m) }
    fun setRoute(r: Int) { service?.setAudioRoute(r) }

    fun dtmf(c: Call, ch: Char) {
        c.playDtmfTone(ch)
        Handler(Looper.getMainLooper()).postDelayed({ c.stopDtmfTone() }, 150)
    }
}
