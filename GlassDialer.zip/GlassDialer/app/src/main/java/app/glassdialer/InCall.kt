package app.glassdialer

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.VideoProfile
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.offset
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt
import app.glassdialer.call.CallManager
import kotlinx.coroutines.delay

class InCallActivity : AppCompatActivity() {
    private var wake: PowerManager.WakeLock? = null

    companion object {
        const val ACTION_ANSWER = "app.glassdialer.ANSWER_FROM_NOTIF"
    }

    private fun handleIntent(i: Intent?) {
        if (i != null && i.action == ACTION_ANSWER) {
            CallManager.calls.value.firstOrNull { it.state == Call.STATE_RINGING }
                ?.let { CallManager.answer(it.call) }
        }
    }

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        applyWindow()
        if (savedInstanceState == null) handleIntent(intent)
        addOnNewIntentListener { handleIntent(it) }
        setContent { AppTheme { InCallScreen(onFinish = { finish() }) } }
    }

    /** Wallpaper mode: window stays see-through and the system blurs the wallpaper behind it. */
    private fun applyWindow() {
        try {
            if (Prefs.callBg == CallBg.WALLPAPER) {
                window.setBackgroundDrawable(ColorDrawable(0x0A000000))
                if (Build.VERSION.SDK_INT >= 31) {
                    val on = windowManager.isCrossWindowBlurEnabled
                    window.setBackgroundBlurRadius(if (on) (Prefs.callBlur * 2.2f).toInt() else 0)
                }
            } else {
                window.setBackgroundDrawable(ColorDrawable(android.graphics.Color.BLACK))
                if (Build.VERSION.SDK_INT >= 31) window.setBackgroundBlurRadius(0)
            }
        } catch (_: Throwable) {
        }
    }

    override fun onResume() {
        super.onResume()
        applyWindow()
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (pm.isWakeLockLevelSupported(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK)) {
                val w = pm.newWakeLock(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK, "glassdialer:prox")
                w.acquire(4 * 3600 * 1000L)
                wake = w
            }
        } catch (_: Throwable) {
        }
    }

    override fun onPause() {
        try {
            wake?.let { if (it.isHeld) it.release() }
        } catch (_: Throwable) {
        }
        wake = null
        super.onPause()
    }
}

private fun blurAvailable(ctx: Context): Boolean = try {
    Build.VERSION.SDK_INT >= 31 &&
        (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).isCrossWindowBlurEnabled
} catch (_: Throwable) {
    false
}

@Composable
private fun CallBackdrop(photo: String?) {
    val ctx = LocalContext.current
    val c = LocalColors.current
    val dim = Prefs.callDim / 100f
    when (Prefs.callBg) {
        CallBg.WALLPAPER -> {
            val extra = if (blurAvailable(ctx)) 0f else 0.25f
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(
                        listOf(
                            Color.Black.copy(alpha = (dim * 0.8f + extra).coerceAtMost(0.9f)),
                            Color.Black.copy(alpha = (dim + extra).coerceAtMost(0.92f))
                        )
                    )
                )
            )
        }

        CallBg.PHOTO -> {
            val bmp by produceState<ImageBitmap?>(null, photo) {
                value = if (photo == null) null else PhotoCache.load(ctx, photo)
            }
            val b = bmp
            if (b != null) {
                Box(Modifier.fillMaxSize().background(Color.Black))
                BlurredBitmap(b.asAndroidBitmap(), Prefs.callBlur, Prefs.callDim)
            } else {
                Box(Modifier.fillMaxSize().background(Color(0xFF0B0B10)))
                Aurora(listOf(c.accent, Color(0xFF7C3AED), Color(0xFF0EA5E9)), 0.5f)
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = dim * 0.5f)))
            }
        }

        CallBg.AURORA -> {
            Box(Modifier.fillMaxSize().background(Color(0xFF0B0B10)))
            Aurora(listOf(c.accent, Color(0xFF7C3AED), Color(0xFF0EA5E9), Color(0xFFEC4899)), 0.55f)
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = dim * 0.5f)))
        }

        CallBg.SOLID -> Box(Modifier.fillMaxSize().background(Color(0xFF0B0B10)))
    }
}

@Composable
private fun Reveal(index: Int, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    var on by remember { mutableStateOf(!Prefs.motion) }
    LaunchedEffect(Unit) {
        delay(index * 70L)
        on = true
    }
    AnimatedVisibility(
        visible = on,
        modifier = modifier,
        enter = fadeIn(tween(420)) + slideInVertically(tween(520, easing = FastOutSlowInEasing)) { it / 5 }
    ) { content() }
}

@Composable
private fun Rings(box: Dp, active: Boolean) {
    if (active && Prefs.motion) {
        val t = rememberInfiniteTransition(label = "rings")
        val p by t.animateFloat(
            initialValue = 0f, targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(2400, easing = LinearEasing), RepeatMode.Restart),
            label = "r"
        )
        Canvas(Modifier.size(box)) {
            val base = this.size.minDimension / 2f
            for (i in 0..2) {
                val q = (p + i / 3f) % 1f
                drawCircle(
                    Color.White.copy(alpha = 0.28f * (1f - q)),
                    radius = base * (0.55f + 0.45f * q),
                    style = Stroke(2.dp.toPx())
                )
            }
        }
    }
}

private val CALL_BTN = 84.dp

@Composable
private fun CallCircle(
    icon: ImageVector,
    label: String?,
    active: Boolean = false,
    enabled: Boolean = true,
    fillColor: Color? = null,
    onClick: () -> Unit
) {
    val fill by animateFloatAsState(if (active) 1f else 0f, tween(220), label = "fill")
    val iconColor by animateColorAsState(
        if (active) Color(0xFF111114) else Color.White, tween(220), label = "ic"
    )
    Column(
        Modifier.bounce(enabled = enabled, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(CALL_BTN).then(
                if (fillColor != null) Modifier.clip(CircleShape).background(fillColor)
                else Modifier.callGlass(CircleShape)
            ),
            contentAlignment = Alignment.Center
        ) {
            if (fillColor == null) {
                Box(Modifier.fillMaxSize().background(Color.White.copy(alpha = fill)))
            }
            Icon(
                icon, null, Modifier.size(30.dp),
                tint = (if (fillColor != null) Color.White else iconColor).copy(alpha = if (enabled) 1f else 0.4f)
            )
        }
        if (label != null) {
            Spacer(Modifier.height(7.dp))
            Text(
                label, color = Color.White.copy(alpha = if (enabled) 0.92f else 0.5f),
                fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1,
                overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
            )
        }
    }
}

/** Equal-width column so every button sits on the same grid. */
@Composable
private fun RowScope.Cell(content: @Composable () -> Unit) {
    Box(Modifier.weight(1f), contentAlignment = Alignment.TopCenter) { content() }
}

@Composable
private fun AddCallPanel(
    number: String,
    onKey: (Char) -> Unit,
    onDelete: () -> Unit,
    onCancel: () -> Unit,
    onCall: () -> Unit
) {
    Column(
        Modifier.fillMaxWidth().callGlass(RoundedCornerShape(32.dp)).padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth().height(44.dp), verticalAlignment = Alignment.CenterVertically) {
            Spacer(Modifier.size(34.dp))
            Text(
                prettyNumber(number), color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Medium,
                maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                modifier = Modifier.weight(1f)
            )
            Box(Modifier.size(34.dp).tap(enabled = number.isNotEmpty()) { onDelete() }, contentAlignment = Alignment.Center) {
                if (number.isNotEmpty()) Icon(Ic.backspace, null, Modifier.size(22.dp), tint = Color.White.copy(alpha = 0.8f))
            }
        }
        KeyGrid(onKey = onKey, tint = Color.White)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(
                Modifier.weight(1f).height(50.dp).bounce { onCancel() }.callGlass(RoundedCornerShape(25.dp)),
                contentAlignment = Alignment.Center
            ) { Text(stringResource(R.string.cancel), color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }
            Row(
                Modifier.weight(1f).height(50.dp).bounce(enabled = number.isNotEmpty()) { onCall() }
                    .clip(RoundedCornerShape(25.dp)).background(Color(0xFF34C759).copy(alpha = if (number.isNotEmpty()) 1f else 0.4f)),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Ic.call, null, Modifier.size(18.dp), tint = Color.White)
                Spacer(Modifier.width(6.dp))
                Text(stringResource(R.string.call), color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

/** Pops in (fade + scale) after a small per-index delay, so a group of buttons appears one after another. */
@Composable
private fun Pop(visible: Boolean, index: Int, content: @Composable () -> Unit) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(visible) {
        if (visible) {
            delay(index * 45L)
            shown = true
        } else {
            shown = false
        }
    }
    AnimatedVisibility(
        visible = shown,
        enter = fadeIn(tween(170)) + scaleIn(tween(260, easing = FastOutSlowInEasing), initialScale = 0.55f),
        exit = fadeOut(tween(120)) + scaleOut(tween(120), targetScale = 0.8f)
    ) { content() }
}

/**
 * Bottom of the call screen.
 *  - ringing: one knob inside a wide bar. Drag left = answer, drag right = decline.
 *  - answered / outgoing: the bar melts away and the knob becomes the red end-call button,
 *    while speaker and keypad pop in beside it.
 */
@Composable
private fun CallBottomBar(
    ringing: Boolean,
    expanded: Boolean,
    enabled: Boolean,
    speakerIcon: ImageVector,
    speakerActive: Boolean,
    keypadActive: Boolean,
    onAnswer: () -> Unit,
    onDecline: () -> Unit,
    onHangup: () -> Unit,
    onSpeaker: () -> Unit,
    onKeypad: () -> Unit
) {
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val knobPx = with(density) { CALL_BTN.toPx() }
    val padPx = with(density) { 6.dp.toPx() }
    var trackW by remember { mutableStateOf(0f) }
    val maxOff = ((trackW - knobPx) / 2f - padPx).coerceAtLeast(1f)
    val off = remember { Animatable(0f) }
    val morph by animateFloatAsState(if (expanded) 1f else 0f, tween(480, easing = FastOutSlowInEasing), label = "morph")
    val red = Color(0xFFFF2D4F)
    val green = Color(0xFF34C759)
    val f = (abs(off.value) / maxOff).coerceIn(0f, 1f)
    val dragColor = if (off.value < 0f) lerp(Color.White, green, f) else lerp(Color.White, red, f)
    val knobColor = lerp(dragColor, red, morph)
    val iconTint = lerp(Color(0xFF111114), Color.White, maxOf(f, morph))
    val fRight = if (off.value > 0f) f else 0f

    Box(
        Modifier.fillMaxWidth().height(CALL_BTN)
            .onSizeChanged { trackW = it.width.toFloat() }
            .draggable(
                orientation = Orientation.Horizontal,
                enabled = ringing && !expanded && enabled,
                state = rememberDraggableState { d ->
                    scope.launch { off.snapTo((off.value + d).coerceIn(-maxOff, maxOff)) }
                },
                onDragStopped = {
                    when {
                        off.value <= -maxOff * 0.7f -> {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            onAnswer()
                            off.animateTo(0f, spring(dampingRatio = 0.6f, stiffness = 260f))
                        }
                        off.value >= maxOff * 0.7f -> {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            onDecline()
                        }
                        else -> off.animateTo(0f, spring(dampingRatio = 0.55f, stiffness = 380f))
                    }
                }
            )
    ) {
        // the wide bar
        Box(
            Modifier.fillMaxSize()
                .graphicsLayer {
                    alpha = 1f - morph
                    scaleX = 1f - 0.45f * morph
                }
                .callGlass(CircleShape)
        )
        // end hints: physical left = answer, physical right = decline
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(
                Modifier.fillMaxSize().padding(horizontal = 26.dp).graphicsLayer { alpha = 1f - morph },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Ic.call, null, Modifier.size(26.dp), tint = green)
                    Spacer(Modifier.width(6.dp))
                    Text("\u2039\u2039\u2039", color = green.copy(alpha = 0.8f), fontSize = 20.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("\u203A\u203A\u203A", color = red.copy(alpha = 0.85f), fontSize = 20.sp)
                    Spacer(Modifier.width(6.dp))
                    Icon(Ic.callEnd, null, Modifier.size(26.dp), tint = red)
                }
            }
        }
        Row(Modifier.fillMaxSize()) {
            Cell {
                Pop(expanded, 6) {
                    CallCircle(speakerIcon, null, active = speakerActive, enabled = enabled, onClick = onSpeaker)
                }
            }
            Cell {
                Box(
                    Modifier.offset { IntOffset(off.value.roundToInt(), 0) }
                        .size(CALL_BTN)
                        .bounce(enabled = expanded && enabled, onClick = onHangup)
                        .clip(CircleShape)
                        .background(knobColor),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Ic.call, null,
                        Modifier.size(36.dp).graphicsLayer {
                            alpha = 1f - morph
                            rotationZ = 135f * fRight * (1f - morph)
                        },
                        tint = iconTint
                    )
                    Icon(
                        Ic.callEnd, null,
                        Modifier.size(36.dp).graphicsLayer { alpha = morph },
                        tint = Color.White
                    )
                }
            }
            Cell {
                Pop(expanded, 7) {
                    CallCircle(Ic.dialpad, null, active = keypadActive, enabled = enabled, onClick = onKeypad)
                }
            }
        }
    }
}

private fun pickPrimary(infos: List<CallManager.Info>): CallManager.Info? =
    infos.firstOrNull { it.state == Call.STATE_RINGING }
        ?: infos.firstOrNull { it.state != Call.STATE_HOLDING }
        ?: infos.firstOrNull()

@Composable
private fun BigButton(color: Color, icon: ImageVector, desc: String, pulse: Boolean = false, onClick: () -> Unit) {
    val t = rememberInfiniteTransition(label = "pulse")
    val s by t.animateFloat(
        initialValue = 1f, targetValue = if (pulse && Prefs.motion) 1.12f else 1f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "s"
    )
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(76.dp).scale(s).bounce(onClick = onClick).clip(CircleShape).background(color),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, Modifier.size(34.dp), tint = Color.White) }
        Spacer(Modifier.height(8.dp))
        Text(desc, color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
    }
}

@Composable
fun InCallScreen(onFinish: () -> Unit) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val infos by CallManager.calls.collectAsState()
    val muted by CallManager.muted.collectAsState()
    val route by CallManager.route.collectAsState()
    val mask by CallManager.routeMask.collectAsState()
    var last by remember { mutableStateOf<CallManager.Info?>(null) }
    var panel by remember { mutableStateOf(0) }
    var typed by remember { mutableStateOf("") }
    var dialNum by remember { mutableStateOf("") }
    var answering by remember { mutableStateOf(false) }
    var noteOpen by remember { mutableStateOf(false) }
    var noteText by remember { mutableStateOf("") }
    var exiting by remember { mutableStateOf(false) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val exitA by animateFloatAsState(if (exiting) 0f else 1f, tween(300), label = "exit")

    val primary = pickPrimary(infos)
    LaunchedEffect(primary) { if (primary != null) last = primary }
    LaunchedEffect(infos.isEmpty()) {
        if (infos.isEmpty()) {
            delay(900)
            exiting = true
            delay(320)
            onFinish()
        } else {
            exiting = false
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(500)
        }
    }
    SideEffect {
        val w = (ctx as? Activity)?.window
        if (w != null) {
            val ctl = WindowCompat.getInsetsController(w, view)
            ctl.isAppearanceLightStatusBars = false
            ctl.isAppearanceLightNavigationBars = false
        }
    }

    val shown = primary ?: last
    LaunchedEffect(shown?.call) { answering = false }
    val number = shown?.number ?: ""
    val contact by produceState(Pair<String?, String?>(null, null), number) {
        value = Repo.lookup(ctx, number)
    }
    val name = contact.first ?: shown?.name?.takeIf { it.isNotBlank() }

    Box(
        Modifier.fillMaxSize().graphicsLayer {
            alpha = exitA
            scaleX = 0.96f + 0.04f * exitA
            scaleY = 0.96f + 0.04f * exitA
        }
    ) {
        CallBackdrop(contact.second)

        if (shown != null) {
            val ended = primary == null
            val ringing = !ended && shown.state == Call.STATE_RINGING
            val expanded = !ringing || answering
            val holding = !ended && shown.state == Call.STATE_HOLDING
            val title = name ?: if (number.isBlank()) stringResource(R.string.private_number) else prettyNumber(number)
            val elapsed = if (shown.connectMs > 0) ((now - shown.connectMs) / 1000).coerceAtLeast(0) else 0L
            val label = when {
                ended -> stringResource(R.string.call_ended)
                shown.state == Call.STATE_RINGING -> stringResource(R.string.incoming_call)
                shown.state == Call.STATE_ACTIVE -> fmtTime(elapsed)
                holding -> stringResource(R.string.on_hold)
                shown.state == Call.STATE_DISCONNECTED || shown.state == Call.STATE_DISCONNECTING ->
                    stringResource(R.string.call_ended)
                else -> stringResource(R.string.calling)
            }
            val badges = listOfNotNull(
                if ((shown.props and Call.Details.PROPERTY_HIGH_DEF_AUDIO) != 0) "HD" else null,
                if ((shown.props and Call.Details.PROPERTY_WIFI) != 0) "Wi-Fi" else null
            ).joinToString("  ·  ")
            val others = infos.filter { it.call !== shown.call }
            val btAvail = (mask and CallAudioState.ROUTE_BLUETOOTH) != 0
            val onSpeaker = route == CallAudioState.ROUTE_SPEAKER
            val onBt = route == CallAudioState.ROUTE_BLUETOOTH
            val cycleAudio = {
                val next = when {
                    onSpeaker -> if (btAvail) CallAudioState.ROUTE_BLUETOOTH else CallAudioState.ROUTE_WIRED_OR_EARPIECE
                    onBt -> CallAudioState.ROUTE_WIRED_OR_EARPIECE
                    else -> CallAudioState.ROUTE_SPEAKER
                }
                CallManager.setRoute(next)
            }
            val red = Color(0xFFFF2D4F)

            Column(
                Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(28.dp))
                if (Prefs.showAvatar && name != null && panel == 0) {
                    Reveal(0) {
                        Box(Modifier.size(210.dp), contentAlignment = Alignment.Center) {
                            Rings(210.dp, ringing)
                            Avatar(name, contact.second, 118.dp)
                        }
                    }
                } else {
                    Spacer(Modifier.height(36.dp))
                }
                Reveal(1) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            title, color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.SemiBold,
                            maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
                        )
                        if (name != null && number.isNotBlank()) {
                            Text(prettyNumber(number), color = Color.White.copy(alpha = 0.75f), fontSize = 16.sp)
                        }
                        if (badges.isNotEmpty()) {
                            Text(badges, color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(label, color = Color.White.copy(alpha = 0.9f), fontSize = 18.sp, fontWeight = FontWeight.Medium)
                    }
                }

                if (others.isNotEmpty() && !ended) {
                    Spacer(Modifier.height(14.dp))
                    others.forEach { o ->
                        Row(
                            Modifier.fillMaxWidth().callGlass(RoundedCornerShape(20.dp))
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    if (!o.name.isNullOrBlank()) o.name else prettyNumber(o.number),
                                    color = Color.White, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                                )
                                Text(stringResource(R.string.call_waiting), color = Color.White.copy(alpha = 0.65f), fontSize = 12.sp)
                            }
                            Text(
                                stringResource(R.string.switch_call), color = Color.White, fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.tap {
                                    CallManager.hold(shown.call, true)
                                    CallManager.hold(o.call, false)
                                }.padding(8.dp)
                            )
                        }
                    }
                }

                Spacer(Modifier.weight(1f))

                if (expanded && !ended) {
                    Crossfade(targetState = panel, label = "panel") { p ->
                        when (p) {
                            0 -> Column {
                                Row(Modifier.fillMaxWidth()) {
                                    Cell {
                                        Pop(true, 0) {
                                            CallCircle(Ic.videocam, stringResource(R.string.video_call)) {
                                                try {
                                                    val vc = shown.call.videoCall
                                                    if (vc != null) {
                                                        vc.sendSessionModifyRequest(VideoProfile(VideoProfile.STATE_BIDIRECTIONAL))
                                                    } else {
                                                        Toast.makeText(ctx, ctx.getString(R.string.video_unsupported), Toast.LENGTH_SHORT).show()
                                                    }
                                                } catch (_: Throwable) {
                                                    Toast.makeText(ctx, ctx.getString(R.string.video_unsupported), Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                        }
                                    }
                                    Cell {
                                        Pop(true, 1) {
                                            CallCircle(Ic.message, stringResource(R.string.message), enabled = number.isNotBlank()) {
                                                safeStart(ctx, smsIntent(number))
                                            }
                                        }
                                    }
                                    Cell {
                                        Pop(true, 2) {
                                            CallCircle(Ic.note, stringResource(R.string.note), enabled = number.isNotBlank()) {
                                                noteText = Prefs.note(number)
                                                noteOpen = true
                                            }
                                        }
                                    }
                                }
                                Spacer(Modifier.height(18.dp))
                                Row(Modifier.fillMaxWidth()) {
                                    Cell {
                                        Pop(true, 3) {
                                            CallCircle(
                                                Ic.micOff,
                                                stringResource(if (muted) R.string.unmute else R.string.mute),
                                                active = muted
                                            ) { CallManager.setMuted(!muted) }
                                        }
                                    }
                                    Cell {
                                        Pop(true, 4) {
                                            CallCircle(
                                                if (holding) Ic.play else Ic.pause,
                                                stringResource(if (holding) R.string.resume else R.string.hold),
                                                active = holding
                                            ) { CallManager.hold(shown.call, !holding) }
                                        }
                                    }
                                    Cell {
                                        Pop(true, 5) {
                                            CallCircle(Ic.add, stringResource(R.string.add_call)) {
                                                dialNum = ""
                                                panel = 2
                                            }
                                        }
                                    }
                                }
                            }

                            1 -> Column(
                                Modifier.fillMaxWidth().callGlass(RoundedCornerShape(32.dp)).padding(14.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    typed, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Medium,
                                    maxLines = 1, modifier = Modifier.height(40.dp)
                                )
                                KeyGrid(onKey = { ch ->
                                    if (typed.length < 40) typed += ch
                                    CallManager.dtmf(shown.call, ch)
                                }, tint = Color.White)
                            }

                            else -> AddCallPanel(
                                number = dialNum,
                                onKey = { ch -> if (dialNum.length < 30) dialNum += ch },
                                onDelete = { dialNum = dialNum.dropLast(1) },
                                onCancel = { panel = 0 },
                                onCall = {
                                    placeCall(ctx, dialNum, shown.call.details?.accountHandle)
                                    dialNum = ""
                                    panel = 0
                                }
                            )
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                }

                Box(Modifier.padding(bottom = 18.dp)) {
                    CallBottomBar(
                        ringing = ringing,
                        expanded = expanded,
                        enabled = !ended,
                        speakerIcon = if (onBt) Ic.bluetooth else Ic.speaker,
                        speakerActive = onSpeaker || onBt,
                        keypadActive = panel == 1,
                        onAnswer = {
                            answering = true
                            CallManager.answer(shown.call)
                        },
                        onDecline = { CallManager.reject(shown.call) },
                        onHangup = { CallManager.hangup(shown.call) },
                        onSpeaker = { cycleAudio() },
                        onKeypad = { panel = if (panel == 1) 0 else 1 }
                    )
                }
            }
        }
    }

    if (noteOpen) {
        AlertDialog(
            onDismissRequest = { noteOpen = false },
            containerColor = Color(0xFF2A2A2C),
            title = { Text(stringResource(R.string.note), color = Color.White) },
            text = {
                BasicTextField(
                    value = noteText,
                    onValueChange = { noteText = it },
                    textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                    cursorBrush = SolidColor(Color.White),
                    modifier = Modifier.fillMaxWidth().height(120.dp)
                        .callGlass(RoundedCornerShape(16.dp)).padding(12.dp),
                    decorationBox = { inner ->
                        Box {
                            if (noteText.isEmpty()) {
                                Text(stringResource(R.string.note_hint), color = Color.White.copy(alpha = 0.5f), fontSize = 16.sp)
                            }
                            inner()
                        }
                    }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    Prefs.updateNote(number, noteText)
                    noteOpen = false
                }) { Text(stringResource(R.string.save), color = Color.White) }
            },
            dismissButton = {
                TextButton(onClick = { noteOpen = false }) {
                    Text(stringResource(R.string.cancel), color = Color.White.copy(alpha = 0.7f))
                }
            }
        )
    }
}
