package app.glassdialer

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.VideoProfile
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.absoluteOffset
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.IntOffset
import kotlinx.coroutines.launch
import kotlin.math.roundToInt
import app.glassdialer.call.CallManager
import kotlinx.coroutines.delay

class InCallActivity : AppCompatActivity() {
    private var wake: PowerManager.WakeLock? = null
    private val audioPermLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) { }

    companion object {
        const val ACTION_ANSWER = "app.glassdialer.ANSWER_FROM_NOTIF"
    }

    private fun handleIntent(i: Intent?) {
        if (i != null && i.action == ACTION_ANSWER) {
            CallManager.calls.value.firstOrNull { it.state == Call.STATE_RINGING }
                ?.let { CallManager.answer(it.call) }
        }
    }

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        )
        WindowCompat.setDecorFitsSystemWindows(window, false)
        applyWindow()
        if (savedInstanceState == null) handleIntent(intent)
        addOnNewIntentListener { handleIntent(it) }
        if (!has(android.Manifest.permission.RECORD_AUDIO)) {
            try {
                audioPermLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
            } catch (_: Throwable) {
            }
        }
        setContent { AppTheme { InCallScreen(onFinish = { finish() }) } }
    }

    /** Wallpaper mode: window stays see-through and the system blurs the wallpaper behind it. */
    private fun applyWindow() {
        try {
            if (Prefs.callBg == CallBg.WALLPAPER) {
                window.setBackgroundDrawable(ColorDrawable(0x0A000000))
                if (Build.VERSION.SDK_INT >= 31) {
                    val on = windowManager.isCrossWindowBlurEnabled
                    window.setBackgroundBlurRadius(if (on) (Prefs.callBlur * 2.2f).toInt() else 0)
                }
            } else {
                window.setBackgroundDrawable(ColorDrawable(android.graphics.Color.BLACK))
                if (Build.VERSION.SDK_INT >= 31) window.setBackgroundBlurRadius(0)
            }
        } catch (_: Throwable) {
        }
    }

    override fun onResume() {
        super.onResume()
        applyWindow()
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (pm.isWakeLockLevelSupported(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK)) {
                val w = pm.newWakeLock(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK, "glassdialer:prox")
                w.acquire(4 * 3600 * 1000L)
                wake = w
            }
        } catch (_: Throwable) {
        }
    }

    override fun onPause() {
        try {
            wake?.let { if (it.isHeld) it.release() }
        } catch (_: Throwable) {
        }
        wake = null
        super.onPause()
    }

}

private fun blurAvailable(ctx: Context): Boolean = try {
    Build.VERSION.SDK_INT >= 31 &&
        (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).isCrossWindowBlurEnabled
} catch (_: Throwable) {
    false
}

@Composable
private fun CallBackdrop(photo: String?) {
    val ctx = LocalContext.current
    val c = LocalColors.current
    val dim = Prefs.callDim / 100f
    when (Prefs.callBg) {
        CallBg.WALLPAPER -> {
            val extra = if (blurAvailable(ctx)) 0f else 0.25f
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(
                        listOf(
                            Color.Black.copy(alpha = (dim * 0.8f + extra).coerceAtMost(0.9f)),
                            Color.Black.copy(alpha = (dim + extra).coerceAtMost(0.92f))
                        )
                    )
                )
            )
        }

        CallBg.PHOTO -> {
            val bmp by produceState<ImageBitmap?>(null, photo) {
                value = if (photo == null) null else PhotoCache.load(ctx, photo)
            }
            val b = bmp
            if (b != null) {
                Box(Modifier.fillMaxSize().background(Color.Black))
                BlurredBitmap(b.asAndroidBitmap(), Prefs.callBlur, Prefs.callDim)
            } else {
                Box(Modifier.fillMaxSize().background(Color(0xFF0B0B10)))
                Aurora(listOf(c.accent, Color(0xFF7C3AED), Color(0xFF0EA5E9)), 0.5f)
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = dim * 0.5f)))
            }
        }

        CallBg.AURORA -> {
            Box(Modifier.fillMaxSize().background(Color(0xFF0B0B10)))
            Aurora(listOf(c.accent, Color(0xFF7C3AED), Color(0xFF0EA5E9), Color(0xFFEC4899)), 0.55f)
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = dim * 0.5f)))
        }

        CallBg.SOLID -> Box(Modifier.fillMaxSize().background(Color(0xFF0B0B10)))
    }
}

@Composable
private fun Reveal(index: Int, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    var on by remember { mutableStateOf(!Prefs.motion) }
    LaunchedEffect(Unit) {
        delay(index * 70L)
        on = true
    }
    AnimatedVisibility(
        visible = on,
        modifier = modifier,
        enter = fadeIn(tween(420)) + slideInVertically(tween(520, easing = FastOutSlowInEasing)) { it / 5 }
    ) { content() }
}

private val CALL_BTN = 78.dp

@Composable
private fun CallCircle(
    icon: ImageVector,
    label: String?,
    active: Boolean = false,
    enabled: Boolean = true,
    fillColor: Color? = null,
    onClick: () -> Unit
) {
    val iconColor = Color.White
    Column(
        Modifier.bounce(enabled = enabled, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(CALL_BTN)
                .clip(CircleShape)
                .background(
                    (fillColor ?: Color(0xFF151619)).copy(alpha = if (active && fillColor == null) 0.92f else 0.72f)
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                icon, null, Modifier.size(32.dp),
                tint = Color.White.copy(alpha = if (enabled) 1f else 0.4f)
            )
        }
        if (label != null) {
            Spacer(Modifier.height(7.dp))
            Text(
                label, color = Color.White.copy(alpha = if (enabled) 0.92f else 0.5f),
                fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1,
                overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
            )
        }
    }
}

/** Equal-width column so every button sits on the same grid. */
@Composable
private fun RowScope.Cell(content: @Composable () -> Unit) {
    Box(Modifier.weight(1f), contentAlignment = Alignment.TopCenter) { content() }
}

@Composable
private fun AddCallPanel(
    number: String,
    contacts: List<ContactEntry>,
    onKey: (Char) -> Unit,
    onDelete: () -> Unit,
    onCancel: () -> Unit,
    onCall: (String) -> Unit
) {
    var tab by remember { mutableStateOf(0) }
    var query by remember { mutableStateOf("") }
    val filtered = remember(contacts, query) {
        if (query.isBlank()) contacts
        else {
            val qd = query.filter { it.isDigit() }.ifEmpty { "\u0000" }
            contacts.filter { it.name.contains(query, ignoreCase = true) || it.number.filter { ch -> ch.isDigit() }.contains(qd) }
        }
    }
    Column(
        Modifier.fillMaxWidth().callGlass(RoundedCornerShape(32.dp)).padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            Modifier.fillMaxWidth().height(36.dp).clip(RoundedCornerShape(18.dp))
                .background(Color.White.copy(alpha = 0.12f))
        ) {
            listOf(R.string.keypad to 0, R.string.contacts to 1).forEach { (res, i) ->
                val sel = tab == i
                Box(
                    Modifier.weight(1f).fillMaxHeight().tap { tab = i }.then(
                        if (sel) Modifier.clip(RoundedCornerShape(18.dp)).background(Color.White.copy(alpha = 0.22f)) else Modifier
                    ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        stringResource(res), color = Color.White.copy(alpha = if (sel) 1f else 0.7f),
                        fontSize = 13.sp, fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        if (tab == 0) {
            Row(Modifier.fillMaxWidth().height(44.dp), verticalAlignment = Alignment.CenterVertically) {
                Spacer(Modifier.size(34.dp))
                Text(
                    prettyNumber(number), color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Medium,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f)
                )
                Box(Modifier.size(34.dp).tap(enabled = number.isNotEmpty()) { onDelete() }, contentAlignment = Alignment.Center) {
                    if (number.isNotEmpty()) Icon(Ic.backspace, null, Modifier.size(22.dp), tint = Color.White.copy(alpha = 0.8f))
                }
            }
            KeyGrid(onKey = onKey, tint = Color.White)
        } else {
            BasicTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                cursorBrush = SolidColor(Color.White),
                decorationBox = { inner ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Ic.search, null, Modifier.size(18.dp), tint = Color.White.copy(alpha = 0.7f))
                        Spacer(Modifier.width(8.dp))
                        Box(Modifier.weight(1f)) {
                            if (query.isEmpty()) {
                                Text(stringResource(R.string.search_contacts), color = Color.White.copy(alpha = 0.6f), fontSize = 15.sp)
                            }
                            inner()
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(40.dp)
                    .clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.10f)).padding(horizontal = 12.dp)
            )
            Spacer(Modifier.height(6.dp))
            LazyColumn(Modifier.fillMaxWidth().heightIn(max = 280.dp)) {
                if (filtered.isEmpty()) {
                    item {
                        Box(Modifier.fillMaxWidth().padding(vertical = 24.dp), contentAlignment = Alignment.Center) {
                            Text(stringResource(R.string.no_contacts), color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp)
                        }
                    }
                }
                items(filtered, key = { it.id.toString() + ":" + Repo.norm(it.number) }) { e ->
                    Row(
                        Modifier.fillMaxWidth().tap { onCall(e.number) }.padding(horizontal = 6.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Avatar(e.name, e.photo, 38.dp)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(e.name, color = Color.White, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(prettyNumber(e.number), color = Color.White.copy(alpha = 0.65f), fontSize = 12.sp)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(
                Modifier.weight(1f).height(50.dp).bounce { onCancel() }.callGlass(RoundedCornerShape(25.dp)),
                contentAlignment = Alignment.Center
            ) { Text(stringResource(R.string.cancel), color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }
            if (tab == 0) {
                Row(
                    Modifier.weight(1f).height(50.dp).bounce(enabled = number.isNotEmpty()) { onCall(number) }
                        .clip(RoundedCornerShape(25.dp)).background(Color(0xFF34C759).copy(alpha = if (number.isNotEmpty()) 1f else 0.4f)),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Ic.call, null, Modifier.size(18.dp), tint = Color.White)
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.call), color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

/** Pops in (fade + scale) after a small per-index delay, so a group of buttons appears one after another. */
@Composable
private fun Pop(visible: Boolean, index: Int, content: @Composable () -> Unit) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(visible) {
        if (visible) {
            delay(index * 45L)
            shown = true
        } else {
            shown = false
        }
    }
    AnimatedVisibility(
        visible = shown,
        enter = fadeIn(tween(170)) + scaleIn(tween(260, easing = FastOutSlowInEasing), initialScale = 0.55f),
        exit = fadeOut(tween(120)) + scaleOut(tween(120), targetScale = 0.8f)
    ) { content() }
}

@Composable
private fun WaveformMark() {
    androidx.compose.foundation.Canvas(Modifier.size(width = 34.dp, height = 30.dp)) {
        val bars = listOf(7f, 13f, 20f, 27f, 17f, 11f, 22f, 15f, 8f)
        val stroke = size.width / 15f
        bars.forEachIndexed { i, h ->
            val x = size.width * (i + 1f) / (bars.size + 1f)
            drawLine(
                color = Color(0xFF111214),
                start = androidx.compose.ui.geometry.Offset(x, (size.height - h) / 2f),
                end = androidx.compose.ui.geometry.Offset(x, (size.height + h) / 2f),
                strokeWidth = stroke,
                cap = androidx.compose.ui.graphics.StrokeCap.Round
            )
        }
    }
}

/** Same chrome as CallCircle, but shows a live mm:ss timer and a pulsing dot while recording. */
@Composable
private fun RecordCell(ctx: Context, number: String, enabled: Boolean) {
    val active by CallRecorder.active.collectAsState()
    val secs by CallRecorder.seconds.collectAsState()
    val pulse = rememberInfiniteTransition(label = "rec")
    val p by pulse.animateFloat(
        initialValue = 0.5f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(650, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "recPulse"
    )
    Column(
        Modifier.bounce(enabled = enabled || active) {
            if (active) {
                CallRecorder.stop()
            } else if (enabled) {
                val ok = CallRecorder.start(ctx, number)
                if (!ok) Toast.makeText(ctx, ctx.getString(R.string.record_failed), Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(ctx, "ابدئي التسجيل بعد اتصال الطرف الآخر", Toast.LENGTH_SHORT).show()
            }
        },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(CALL_BTN).clip(CircleShape)
                .background(if (active) Color(0xFFFFF0F0) else Color(0xFFE7E7E9)),
            contentAlignment = Alignment.Center
        ) {
            if (active) {
                Box(
                    Modifier.size(14.dp).graphicsLayer { alpha = p }
                        .clip(CircleShape).background(Color(0xFFFF2D2D))
                )
            } else {
                WaveformMark()
            }
        }
        Spacer(Modifier.height(7.dp))
        Text(
            if (active) fmtTime(secs) else stringResource(R.string.record),
            color = Color.White.copy(alpha = 0.92f), fontSize = 12.sp, fontWeight = FontWeight.Medium,
            maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
        )
    }
}

/** A round button you drag straight up to trigger; a small hint chevron bobs above it while idle. */
@Composable
private fun SwipeUpButton(
    color: Color,
    icon: ImageVector,
    label: String,
    enabled: Boolean,
    showHint: Boolean = true,
    onTrigger: () -> Unit
) {
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val thresholdPx = with(density) { 64.dp.toPx() }
    val maxPx = with(density) { 108.dp.toPx() }
    val dy = remember { Animatable(0f) }
    var dragging by remember { mutableStateOf(false) }
    val progress = (-dy.value / thresholdPx).coerceIn(0f, 1f)
    val scale = 1f + 0.08f * progress

    val hint = rememberInfiniteTransition(label = "hint")
    val bob by hint.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(850, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "bob"
    )
    val hintAlpha by animateFloatAsState(if (dragging || !showHint) 0f else 1f, tween(160), label = "hintAlpha")

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(
            Ic.keyboardUp, null,
            Modifier.size(22.dp).graphicsLayer {
                alpha = hintAlpha * 0.85f
                translationY = -bob * 8f
            },
            tint = Color.White
        )
        Spacer(Modifier.height(2.dp))
        Box(
            Modifier
                .absoluteOffset { IntOffset(0, dy.value.roundToInt()) }
                .graphicsLayer { scaleX = scale; scaleY = scale }
                .size(78.dp)
                .draggable(
                    orientation = Orientation.Vertical,
                    enabled = enabled,
                    state = rememberDraggableState { d ->
                        scope.launch {
                            dy.snapTo((dy.value + d).coerceIn(-maxPx, 0f))
                            if (!dragging) dragging = true
                        }
                    },
                    onDragStarted = { dragging = true },
                    onDragStopped = {
                        if (-dy.value >= thresholdPx) {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            onTrigger()
                        }
                        dragging = false
                        scope.launch { dy.animateTo(0f, spring(dampingRatio = 0.55f, stiffness = 380f)) }
                    }
                )
                .clip(CircleShape)
                .background(color),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, Modifier.size(32.dp), tint = Color.White) }
        Spacer(Modifier.height(8.dp))
        Text(label, color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun CallBottomBar(
    ringing: Boolean,
    expanded: Boolean,
    enabled: Boolean,
    speakerIcon: ImageVector,
    speakerActive: Boolean,
    keypadActive: Boolean,
    onAnswer: () -> Unit,
    onDecline: () -> Unit,
    onHangup: () -> Unit,
    onSpeaker: () -> Unit,
    onKeypad: () -> Unit
) {
    val red = Color(0xFFFF2D4F)
    val green = Color(0xFF34C759)

    Box(Modifier.fillMaxWidth().height(if (ringing) 150.dp else CALL_BTN)) {
        AnimatedVisibility(
            visible = ringing,
            enter = fadeIn(tween(200)),
            exit = fadeOut(tween(160)),
            modifier = Modifier.align(Alignment.Center)
        ) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 44.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                SwipeUpButton(red, Ic.callEnd, stringResource(R.string.decline), enabled, showHint = false, onTrigger = onDecline)
                SwipeUpButton(green, Ic.call, stringResource(R.string.answer), enabled, showHint = true, onTrigger = onAnswer)
            }
        }
        AnimatedVisibility(
            visible = !ringing,
            enter = fadeIn(tween(260, delayMillis = 120)),
            exit = fadeOut(tween(160)),
            modifier = Modifier.align(Alignment.Center)
        ) {
            Row(Modifier.fillMaxWidth()) {
                Cell {
                    Pop(expanded, 6) {
                        CallCircle(speakerIcon, null, active = speakerActive, enabled = enabled, onClick = onSpeaker)
                    }
                }
                Cell {
                    Box(
                        Modifier.size(84.dp).bounce(enabled = enabled, onClick = onHangup)
                            .clip(CircleShape).background(Color(0xFFFF302D)),
                        contentAlignment = Alignment.Center
                    ) { Icon(Ic.callEnd, null, Modifier.size(36.dp), tint = Color.White) }
                }
                Cell {
                    Pop(expanded, 7) {
                        CallCircle(Ic.dialpad, null, active = keypadActive, enabled = enabled, onClick = onKeypad)
                    }
                }
            }
        }
    }
}

private fun pickPrimary(infos: List<CallManager.Info>): CallManager.Info? =
    infos.firstOrNull { it.state == Call.STATE_RINGING }
        ?: infos.firstOrNull { it.state != Call.STATE_HOLDING }
        ?: infos.firstOrNull()

@Composable
private fun BigButton(color: Color, icon: ImageVector, desc: String, pulse: Boolean = false, onClick: () -> Unit) {
    val t = rememberInfiniteTransition(label = "pulse")
    val s by t.animateFloat(
        initialValue = 1f, targetValue = if (pulse && Prefs.motion) 1.12f else 1f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "s"
    )
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(76.dp).scale(s).bounce(onClick = onClick).clip(CircleShape).background(color),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, Modifier.size(34.dp), tint = Color.White) }
        Spacer(Modifier.height(8.dp))
        Text(desc, color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
    }
}

@Composable
fun InCallScreen(onFinish: () -> Unit) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val infos by CallManager.calls.collectAsState()
    val muted by CallManager.muted.collectAsState()
    val route by CallManager.route.collectAsState()
    val mask by CallManager.routeMask.collectAsState()
    var last by remember { mutableStateOf<CallManager.Info?>(null) }
    var panel by remember { mutableStateOf(0) }
    var typed by remember { mutableStateOf("") }
    var dialNum by remember { mutableStateOf("") }
    var answering by remember { mutableStateOf(false) }
    var noteOpen by remember { mutableStateOf(false) }
    var noteText by remember { mutableStateOf("") }
    var exiting by remember { mutableStateOf(false) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val exitA by animateFloatAsState(if (exiting) 0f else 1f, tween(300), label = "exit")

    val primary = pickPrimary(infos)
    LaunchedEffect(primary) { if (primary != null) last = primary }
    LaunchedEffect(infos.isEmpty()) {
        if (infos.isEmpty()) {
            CallRecorder.stop()
            delay(900)
            exiting = true
            delay(320)
            onFinish()
        } else {
            exiting = false
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(500)
        }
    }
    SideEffect {
        val w = (ctx as? Activity)?.window
        if (w != null) {
            val ctl = WindowCompat.getInsetsController(w, view)
            ctl.isAppearanceLightStatusBars = false
            ctl.isAppearanceLightNavigationBars = false
        }
    }

    val shown = primary ?: last
    LaunchedEffect(shown?.call) { answering = false }
    val number = shown?.number ?: ""
    val contact by produceState(Pair<String?, String?>(null, null), number) {
        value = Repo.lookup(ctx, number)
    }
    val name = contact.first ?: shown?.name?.takeIf { it.isNotBlank() }
    val contacts by produceState(emptyList<ContactEntry>(), Unit) { value = Repo.contacts(ctx) }

    Box(
        Modifier.fillMaxSize().graphicsLayer {
            alpha = exitA
            scaleX = 0.96f + 0.04f * exitA
            scaleY = 0.96f + 0.04f * exitA
        }
    ) {
        CallBackdrop(contact.second)

        if (shown != null) {
            val ended = primary == null
            val ringing = !ended && shown.state == Call.STATE_RINGING
            val expanded = !ringing || answering
            val holding = !ended && shown.state == Call.STATE_HOLDING
            val title = name ?: if (number.isBlank()) stringResource(R.string.private_number) else prettyNumber(number)
            val elapsed = if (shown.connectMs > 0) ((now - shown.connectMs) / 1000).coerceAtLeast(0) else 0L
            val label = when {
                ended -> stringResource(R.string.call_ended)
                shown.state == Call.STATE_RINGING -> stringResource(R.string.incoming_call)
                shown.state == Call.STATE_ACTIVE -> fmtTime(elapsed)
                holding -> stringResource(R.string.on_hold)
                shown.state == Call.STATE_DISCONNECTED || shown.state == Call.STATE_DISCONNECTING ->
                    stringResource(R.string.call_ended)
                else -> stringResource(R.string.calling)
            }
            val badges = listOfNotNull(
                if ((shown.props and Call.Details.PROPERTY_HIGH_DEF_AUDIO) != 0) "HD" else null,
                if ((shown.props and Call.Details.PROPERTY_WIFI) != 0) "Wi-Fi" else null
            ).joinToString("  ·  ")
            val others = infos.filter { it.call !== shown.call }
            val btAvail = (mask and CallAudioState.ROUTE_BLUETOOTH) != 0
            val onSpeaker = route == CallAudioState.ROUTE_SPEAKER
            val onBt = route == CallAudioState.ROUTE_BLUETOOTH
            val cycleAudio = {
                val next = when {
                    onSpeaker -> if (btAvail) CallAudioState.ROUTE_BLUETOOTH else CallAudioState.ROUTE_WIRED_OR_EARPIECE
                    onBt -> CallAudioState.ROUTE_WIRED_OR_EARPIECE
                    else -> CallAudioState.ROUTE_SPEAKER
                }
                CallManager.setRoute(next)
            }
            val red = Color(0xFFFF2D4F)

            Column(
                Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(28.dp))
                if (Prefs.showAvatar && name != null && panel == 0) {
                    Reveal(0) {
                        Avatar(name, contact.second, 118.dp)
                    }
                } else {
                    Spacer(Modifier.height(36.dp))
                }
                Reveal(1) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            title, color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.SemiBold,
                            maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
                        )
                        if (name != null && number.isNotBlank()) {
                            Text(prettyNumber(number), color = Color.White.copy(alpha = 0.75f), fontSize = 16.sp)
                        }
                        if (badges.isNotEmpty()) {
                            Text(badges, color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(label, color = Color.White.copy(alpha = 0.9f), fontSize = 18.sp, fontWeight = FontWeight.Medium)
                    }
                }

                if (others.isNotEmpty() && !ended) {
                    Spacer(Modifier.height(14.dp))
                    others.forEach { o ->
                        Row(
                            Modifier.fillMaxWidth().callGlass(RoundedCornerShape(20.dp))
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    if (!o.name.isNullOrBlank()) o.name else prettyNumber(o.number),
                                    color = Color.White, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                                )
                                Text(stringResource(R.string.call_waiting), color = Color.White.copy(alpha = 0.65f), fontSize = 12.sp)
                            }
                            Text(
                                stringResource(R.string.switch_call), color = Color.White, fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.tap {
                                    CallManager.hold(shown.call, true)
                                    CallManager.hold(o.call, false)
                                }.padding(8.dp)
                            )
                        }
                    }
                }

                Spacer(Modifier.weight(1f))

                if (expanded && !ended) {
                    AnimatedContent(
                        targetState = panel,
                        transitionSpec = {
                            (fadeIn(tween(220)) togetherWith fadeOut(tween(140))) using
                                SizeTransform(clip = false) { _, _ -> tween(260, easing = FastOutSlowInEasing) }
                        },
                        label = "panel"
                    ) { p ->
                        when (p) {
                            0 -> Column {
                                Row(Modifier.fillMaxWidth()) {
                                    Cell {
                                        Pop(true, 0) {
                                            CallCircle(Ic.videocam, stringResource(R.string.video_call)) {
                                                try {
                                                    val vc = shown.call.videoCall
                                                    if (vc != null) {
                                                        vc.sendSessionModifyRequest(VideoProfile(VideoProfile.STATE_BIDIRECTIONAL))
                                                    } else {
                                                        Toast.makeText(ctx, ctx.getString(R.string.video_unsupported), Toast.LENGTH_SHORT).show()
                                                    }
                                                } catch (_: Throwable) {
                                                    Toast.makeText(ctx, ctx.getString(R.string.video_unsupported), Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                        }
                                    }
                                    Cell {
                                        Pop(true, 1) {
                                            CallCircle(Ic.add, stringResource(R.string.add_call)) {
                                                dialNum = ""
                                                panel = 2
                                            }
                                        }
                                    }
                                    Cell {
                                        Pop(true, 2) {
                                            CallCircle(Ic.noteDocIcon, stringResource(R.string.note), enabled = number.isNotBlank()) {
                                                noteText = Prefs.note(number)
                                                noteOpen = true
                                            }
                                        }
                                    }
                                }
                                Spacer(Modifier.height(30.dp))
                                Row(Modifier.fillMaxWidth()) {
                                    Cell {
                                        Pop(true, 3) {
                                            CallCircle(
                                                Ic.micOff,
                                                stringResource(if (muted) R.string.unmute else R.string.mute),
                                                active = muted
                                            ) { CallManager.setMuted(!muted) }
                                        }
                                    }
                                    Cell {
                                        Pop(true, 4) {
                                            CallCircle(
                                                if (holding) Ic.play else Ic.pause,
                                                stringResource(if (holding) R.string.resume else R.string.hold),
                                                active = holding
                                            ) { CallManager.hold(shown.call, !holding) }
                                        }
                                    }
                                    Cell {
                                        Pop(true, 5) {
                                            RecordCell(ctx, number, shown.state == Call.STATE_ACTIVE)
                                        }
                                    }
                                }
                            }

                            1 -> Column(
                                Modifier.fillMaxWidth().callGlass(RoundedCornerShape(32.dp)).padding(14.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    typed, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Medium,
                                    maxLines = 1, modifier = Modifier.height(40.dp)
                                )
                                KeyGrid(onKey = { ch ->
                                    if (typed.length < 40) typed += ch
                                    CallManager.dtmf(shown.call, ch)
                                }, tint = Color.White)
                            }

                            else -> AddCallPanel(
                                number = dialNum,
                                contacts = contacts,
                                onKey = { ch -> if (dialNum.length < 30) dialNum += ch },
                                onDelete = { dialNum = dialNum.dropLast(1) },
                                onCancel = { panel = 0 },
                                onCall = { num ->
                                    placeCall(ctx, num, shown.call.details?.accountHandle)
                                    dialNum = ""
                                    panel = 0
                                }
                            )
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                }

                Spacer(Modifier.height(if (expanded && !ended) 22.dp else 0.dp))

                Box(Modifier.padding(bottom = 18.dp)) {
                    CallBottomBar(
                        ringing = ringing,
                        expanded = expanded,
                        enabled = !ended,
                        speakerIcon = if (onBt) Ic.bluetooth else Ic.volumeUp,
                        speakerActive = onSpeaker || onBt,
                        keypadActive = panel == 1,
                        onAnswer = {
                            answering = true
                            CallManager.answer(shown.call)
                        },
                        onDecline = { CallManager.reject(shown.call) },
                        onHangup = { CallManager.hangup(shown.call) },
                        onSpeaker = { cycleAudio() },
                        onKeypad = { panel = if (panel == 1) 0 else 1 }
                    )
                }
            }
        }
    }

    if (noteOpen) {
        AlertDialog(
            onDismissRequest = { noteOpen = false },
            containerColor = Color(0xFF2A2A2C),
            title = { Text(stringResource(R.string.note), color = Color.White) },
            text = {
                BasicTextField(
                    value = noteText,
                    onValueChange = { noteText = it },
                    textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                    cursorBrush = SolidColor(Color.White),
                    modifier = Modifier.fillMaxWidth().height(120.dp)
                        .callGlass(RoundedCornerShape(16.dp)).padding(12.dp),
                    decorationBox = { inner ->
                        Box {
                            if (noteText.isEmpty()) {
                                Text(stringResource(R.string.note_hint), color = Color.White.copy(alpha = 0.5f), fontSize = 16.sp)
                            }
                            inner()
                        }
                    }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    Prefs.updateNote(number, noteText)
                    noteOpen = false
                }) { Text(stringResource(R.string.save), color = Color.White) }
            },
            dismissButton = {
                TextButton(onClick = { noteOpen = false }) {
                    Text(stringResource(R.string.cancel), color = Color.White.copy(alpha = 0.7f))
                }
            }
        )
    }
}
