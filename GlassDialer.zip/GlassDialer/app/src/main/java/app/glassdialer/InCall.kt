package app.glassdialer

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.VideoProfile
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateColorAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import app.glassdialer.call.CallManager
import kotlinx.coroutines.delay

class InCallActivity : AppCompatActivity() {
    private var wake: PowerManager.WakeLock? = null

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        applyWindow()
        setContent { AppTheme { InCallScreen(onFinish = { finish() }) } }
    }

    /** Wallpaper mode: window stays see-through and the system blurs the wallpaper behind it. */
    private fun applyWindow() {
        try {
            if (Prefs.callBg == CallBg.WALLPAPER) {
                window.setBackgroundDrawable(ColorDrawable(0x0A000000))
                if (Build.VERSION.SDK_INT >= 31) {
                    val on = windowManager.isCrossWindowBlurEnabled
                    window.setBackgroundBlurRadius(if (on) (Prefs.callBlur * 2.2f).toInt() else 0)
                }
            } else {
                window.setBackgroundDrawable(ColorDrawable(android.graphics.Color.BLACK))
                if (Build.VERSION.SDK_INT >= 31) window.setBackgroundBlurRadius(0)
            }
        } catch (_: Throwable) {
        }
    }

    override fun onResume() {
        super.onResume()
        applyWindow()
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (pm.isWakeLockLevelSupported(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK)) {
                val w = pm.newWakeLock(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK, "glassdialer:prox")
                w.acquire(4 * 3600 * 1000L)
                wake = w
            }
        } catch (_: Throwable) {
        }
    }

    override fun onPause() {
        try {
            wake?.let { if (it.isHeld) it.release() }
        } catch (_: Throwable) {
        }
        wake = null
        super.onPause()
    }
}

private fun blurAvailable(ctx: Context): Boolean = try {
    Build.VERSION.SDK_INT >= 31 &&
        (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).isCrossWindowBlurEnabled
} catch (_: Throwable) {
    false
}

@Composable
private fun CallBackdrop(photo: String?) {
    val ctx = LocalContext.current
    val c = LocalColors.current
    val dim = Prefs.callDim / 100f
    when (Prefs.callBg) {
        CallBg.WALLPAPER -> {
            val extra = if (blurAvailable(ctx)) 0f else 0.25f
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(
                        listOf(
                            Color.Black.copy(alpha = (dim * 0.8f + extra).coerceAtMost(0.9f)),
                            Color.Black.copy(alpha = (dim + extra).coerceAtMost(0.92f))
                        )
                    )
                )
            )
        }

        CallBg.PHOTO -> {
            val bmp by produceState<ImageBitmap?>(null, photo) {
                value = if (photo == null) null else PhotoCache.load(ctx, photo)
            }
            val b = bmp
            if (b != null) {
                Box(Modifier.fillMaxSize().background(Color.Black))
                BlurredBitmap(b.asAndroidBitmap(), Prefs.callBlur, Prefs.callDim)
            } else {
                Box(Modifier.fillMaxSize().background(Color(0xFF0B0B10)))
                Aurora(listOf(c.accent, Color(0xFF7C3AED), Color(0xFF0EA5E9)), 0.5f)
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = dim * 0.5f)))
            }
        }

        CallBg.AURORA -> {
            Box(Modifier.fillMaxSize().background(Color(0xFF0B0B10)))
            Aurora(listOf(c.accent, Color(0xFF7C3AED), Color(0xFF0EA5E9), Color(0xFFEC4899)), 0.55f)
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = dim * 0.5f)))
        }

        CallBg.SOLID -> Box(Modifier.fillMaxSize().background(Color(0xFF0B0B10)))
    }
}

@Composable
private fun Reveal(index: Int, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    var on by remember { mutableStateOf(!Prefs.motion) }
    LaunchedEffect(Unit) {
        delay(index * 70L)
        on = true
    }
    AnimatedVisibility(
        visible = on,
        modifier = modifier,
        enter = fadeIn(tween(420)) + slideInVertically(tween(520, easing = FastOutSlowInEasing)) { it / 5 }
    ) { content() }
}

@Composable
private fun Rings(box: Dp, active: Boolean) {
    if (active && Prefs.motion) {
        val t = rememberInfiniteTransition(label = "rings")
        val p by t.animateFloat(
            initialValue = 0f, targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(2400, easing = LinearEasing), RepeatMode.Restart),
            label = "r"
        )
        Canvas(Modifier.size(box)) {
            val base = this.size.minDimension / 2f
            for (i in 0..2) {
                val q = (p + i / 3f) % 1f
                drawCircle(
                    Color.White.copy(alpha = 0.28f * (1f - q)),
                    radius = base * (0.55f + 0.45f * q),
                    style = Stroke(2.dp.toPx())
                )
            }
        }
    }
}

@Composable
private fun CallCircle(
    icon: ImageVector,
    label: String?,
    active: Boolean = false,
    enabled: Boolean = true,
    size: Dp = 68.dp,
    onClick: () -> Unit
) {
    val fill by animateFloatAsState(if (active) 1f else 0f, tween(220), label = "fill")
    val iconColor by animateColorAsState(
        if (active) Color(0xFF111114) else Color.White, tween(220), label = "ic"
    )
    Column(
        Modifier.width(if (label != null) 96.dp else size).bounce(enabled = enabled, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(size).callGlass(CircleShape), contentAlignment = Alignment.Center) {
            Box(Modifier.fillMaxSize().background(Color.White.copy(alpha = fill)))
            Icon(
                icon, null, Modifier.size(size * 0.42f),
                tint = iconColor.copy(alpha = if (enabled) 1f else 0.4f)
            )
        }
        if (label != null) {
            Spacer(Modifier.height(7.dp))
            Text(
                label, color = Color.White.copy(alpha = if (enabled) 0.92f else 0.5f),
                fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1,
                overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun BigButton(color: Color, icon: ImageVector, desc: String, pulse: Boolean = false, onClick: () -> Unit) {
    val t = rememberInfiniteTransition(label = "pulse")
    val s by t.animateFloat(
        initialValue = 1f, targetValue = if (pulse && Prefs.motion) 1.12f else 1f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "s"
    )
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(76.dp).scale(s).bounce(onClick = onClick).clip(CircleShape).background(color),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, Modifier.size(34.dp), tint = Color.White) }
        Spacer(Modifier.height(8.dp))
        Text(desc, color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
    }
}

@Composable
fun InCallScreen(onFinish: () -> Unit) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val infos by CallManager.calls.collectAsState()
    val muted by CallManager.muted.collectAsState()
    val route by CallManager.route.collectAsState()
    val mask by CallManager.routeMask.collectAsState()
    var last by remember { mutableStateOf<CallManager.Info?>(null) }
    var showKeys by remember { mutableStateOf(false) }
    var typed by remember { mutableStateOf("") }
    var noteOpen by remember { mutableStateOf(false) }
    var noteText by remember { mutableStateOf("") }
    var exiting by remember { mutableStateOf(false) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val exitA by animateFloatAsState(if (exiting) 0f else 1f, tween(300), label = "exit")

    val primary = infos.firstOrNull { it.state == Call.STATE_RINGING } ?: infos.firstOrNull()
    LaunchedEffect(primary) { if (primary != null) last = primary }
    LaunchedEffect(infos.isEmpty()) {
        if (infos.isEmpty()) {
            delay(900)
            exiting = true
            delay(320)
            onFinish()
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(500)
        }
    }
    SideEffect {
        val w = (ctx as? Activity)?.window
        if (w != null) {
            val ctl = WindowCompat.getInsetsController(w, view)
            ctl.isAppearanceLightStatusBars = false
            ctl.isAppearanceLightNavigationBars = false
        }
    }

    val shown = primary ?: last
    val number = shown?.number ?: ""
    val contact by produceState(Pair<String?, String?>(null, null), number) {
        value = Repo.lookup(ctx, number)
    }
    val name = contact.first ?: shown?.name?.takeIf { it.isNotBlank() }

    Box(
        Modifier.fillMaxSize().graphicsLayer {
            alpha = exitA
            scaleX = 0.96f + 0.04f * exitA
            scaleY = 0.96f + 0.04f * exitA
        }
    ) {
        CallBackdrop(contact.second)

        if (shown != null) {
            val ended = primary == null
            val ringing = !ended && shown.state == Call.STATE_RINGING
            val holding = !ended && shown.state == Call.STATE_HOLDING
            val title = name ?: if (number.isBlank()) stringResource(R.string.private_number) else prettyNumber(number)
            val elapsed = if (shown.connectMs > 0) ((now - shown.connectMs) / 1000).coerceAtLeast(0) else 0L
            val label = when {
                ended -> stringResource(R.string.call_ended)
                shown.state == Call.STATE_RINGING -> stringResource(R.string.incoming_call)
                shown.state == Call.STATE_ACTIVE -> fmtTime(elapsed)
                holding -> stringResource(R.string.on_hold)
                shown.state == Call.STATE_DISCONNECTED || shown.state == Call.STATE_DISCONNECTING ->
                    stringResource(R.string.call_ended)
                else -> stringResource(R.string.calling)
            }
            val badges = listOfNotNull(
                if ((shown.props and Call.Details.PROPERTY_HIGH_DEF_AUDIO) != 0) "HD" else null,
                if ((shown.props and Call.Details.PROPERTY_WIFI) != 0) "Wi-Fi" else null
            ).joinToString("  ·  ")
            val others = infos.filter { it.call !== shown.call }
            val btAvail = (mask and CallAudioState.ROUTE_BLUETOOTH) != 0
            val onSpeaker = route == CallAudioState.ROUTE_SPEAKER
            val onBt = route == CallAudioState.ROUTE_BLUETOOTH
            val cycleAudio = {
                val next = when {
                    onSpeaker -> if (btAvail) CallAudioState.ROUTE_BLUETOOTH else CallAudioState.ROUTE_WIRED_OR_EARPIECE
                    onBt -> CallAudioState.ROUTE_WIRED_OR_EARPIECE
                    else -> CallAudioState.ROUTE_SPEAKER
                }
                CallManager.setRoute(next)
            }
            val red = Color(0xFFFF2D4F)

            Column(
                Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(28.dp))
                if (Prefs.showAvatar && name != null) {
                    Reveal(0) {
                        Box(Modifier.size(210.dp), contentAlignment = Alignment.Center) {
                            Rings(210.dp, ringing)
                            Avatar(name, contact.second, 118.dp)
                        }
                    }
                } else {
                    Spacer(Modifier.height(36.dp))
                }
                Reveal(1) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            title, color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.SemiBold,
                            maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
                        )
                        if (name != null && number.isNotBlank()) {
                            Text(prettyNumber(number), color = Color.White.copy(alpha = 0.75f), fontSize = 16.sp)
                        }
                        if (badges.isNotEmpty()) {
                            Text(badges, color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(label, color = Color.White.copy(alpha = 0.9f), fontSize = 18.sp, fontWeight = FontWeight.Medium)
                    }
                }

                if (others.isNotEmpty() && !ended) {
                    Spacer(Modifier.height(14.dp))
                    others.forEach { o ->
                        Row(
                            Modifier.fillMaxWidth().callGlass(RoundedCornerShape(20.dp))
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    if (!o.name.isNullOrBlank()) o.name else prettyNumber(o.number),
                                    color = Color.White, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                                )
                                Text(stringResource(R.string.call_waiting), color = Color.White.copy(alpha = 0.65f), fontSize = 12.sp)
                            }
                            Text(
                                stringResource(R.string.switch_call), color = Color.White, fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.tap {
                                    CallManager.hold(shown.call, true)
                                    CallManager.hold(o.call, false)
                                }.padding(8.dp)
                            )
                        }
                    }
                }

                Spacer(Modifier.weight(1f))

                if (ringing) {
                    Reveal(2) {
                        Row(
                            Modifier.fillMaxWidth().padding(bottom = 36.dp),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            BigButton(red, Ic.callEnd, stringResource(R.string.decline)) { CallManager.reject(shown.call) }
                            BigButton(Color(0xFF34C759), Ic.call, stringResource(R.string.answer), pulse = true) {
                                CallManager.answer(shown.call)
                            }
                        }
                    }
                } else {
                    Reveal(2) {
                        Crossfade(targetState = showKeys, label = "keys") { k ->
                            if (!k) {
                                Column {
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                                        CallCircle(Ic.videocam, stringResource(R.string.video_call), enabled = !ended) {
                                            try {
                                                val vc = shown.call.videoCall
                                                if (vc != null) {
                                                    vc.sendSessionModifyRequest(VideoProfile(VideoProfile.STATE_BIDIRECTIONAL))
                                                } else {
                                                    Toast.makeText(ctx, ctx.getString(R.string.video_unsupported), Toast.LENGTH_SHORT).show()
                                                }
                                            } catch (_: Throwable) {
                                                Toast.makeText(ctx, ctx.getString(R.string.video_unsupported), Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                        CallCircle(Ic.message, stringResource(R.string.message), enabled = !ended && number.isNotBlank()) {
                                            safeStart(ctx, smsIntent(number))
                                        }
                                        CallCircle(Ic.note, stringResource(R.string.note), enabled = !ended && number.isNotBlank()) {
                                            noteText = Prefs.note(number)
                                            noteOpen = true
                                        }
                                    }
                                    Spacer(Modifier.height(20.dp))
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                                        CallCircle(
                                            if (muted) Ic.micOff else Ic.mic,
                                            stringResource(if (muted) R.string.unmute else R.string.mute),
                                            active = muted, enabled = !ended
                                        ) { CallManager.setMuted(!muted) }
                                        CallCircle(
                                            if (holding) Ic.play else Ic.pause,
                                            stringResource(if (holding) R.string.resume else R.string.hold),
                                            active = holding, enabled = !ended
                                        ) { CallManager.hold(shown.call, !holding) }
                                        CallCircle(Ic.add, stringResource(R.string.add_call), enabled = !ended) {
                                            safeStart(ctx, Intent(Intent.ACTION_DIAL).setClass(ctx, MainActivity::class.java))
                                        }
                                    }
                                }
                            } else {
                                Column(
                                    Modifier.fillMaxWidth().callGlass(RoundedCornerShape(32.dp)).padding(14.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        typed, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Medium,
                                        maxLines = 1, modifier = Modifier.height(40.dp)
                                    )
                                    KeyGrid(onKey = { ch ->
                                        typed += ch
                                        CallManager.dtmf(shown.call, ch)
                                    }, tint = Color.White)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(22.dp))
                    Reveal(3) {
                        Row(
                            Modifier.fillMaxWidth().padding(bottom = 18.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.width(96.dp), contentAlignment = Alignment.Center) {
                                CallCircle(
                                    if (onBt) Ic.bluetooth else Ic.volumeUp, null,
                                    active = onSpeaker || onBt, enabled = !ended, size = 64.dp
                                ) { cycleAudio() }
                            }
                            Box(
                                Modifier.size(76.dp).bounce { CallManager.hangup(shown.call) }
                                    .clip(CircleShape).background(red),
                                contentAlignment = Alignment.Center
                            ) { Icon(Ic.callEnd, stringResource(R.string.end_call), Modifier.size(34.dp), tint = Color.White) }
                            Box(Modifier.width(96.dp), contentAlignment = Alignment.Center) {
                                CallCircle(Ic.dialpad, null, active = showKeys, enabled = !ended, size = 64.dp) {
                                    showKeys = !showKeys
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (noteOpen) {
        AlertDialog(
            onDismissRequest = { noteOpen = false },
            containerColor = Color(0xFF2A2A2C),
            title = { Text(stringResource(R.string.note), color = Color.White) },
            text = {
                BasicTextField(
                    value = noteText,
                    onValueChange = { noteText = it },
                    textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                    cursorBrush = SolidColor(Color.White),
                    modifier = Modifier.fillMaxWidth().height(120.dp)
                        .callGlass(RoundedCornerShape(16.dp)).padding(12.dp),
                    decorationBox = { inner ->
                        Box {
                            if (noteText.isEmpty()) {
                                Text(stringResource(R.string.note_hint), color = Color.White.copy(alpha = 0.5f), fontSize = 16.sp)
                            }
                            inner()
                        }
                    }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    Prefs.updateNote(number, noteText)
                    noteOpen = false
                }) { Text(stringResource(R.string.save), color = Color.White) }
            },
            dismissButton = {
                TextButton(onClick = { noteOpen = false }) {
                    Text(stringResource(R.string.cancel), color = Color.White.copy(alpha = 0.7f))
                }
            }
        )
    }
}
