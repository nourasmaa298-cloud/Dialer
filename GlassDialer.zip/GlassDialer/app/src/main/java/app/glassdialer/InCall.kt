package app.glassdialer

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.telecom.Call
import android.telecom.CallAudioState
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import app.glassdialer.call.CallManager
import kotlinx.coroutines.delay

class InCallActivity : AppCompatActivity() {
    private var wake: PowerManager.WakeLock? = null

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent {
            AppTheme { AppBackground { InCallScreen(onFinish = { finish() }) } }
        }
    }

    override fun onResume() {
        super.onResume()
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (pm.isWakeLockLevelSupported(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK)) {
                val w = pm.newWakeLock(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK, "glassdialer:prox")
                w.acquire(4 * 3600 * 1000L)
                wake = w
            }
        } catch (_: Throwable) {
        }
    }

    override fun onPause() {
        try {
            wake?.let { if (it.isHeld) it.release() }
        } catch (_: Throwable) {
        }
        wake = null
        super.onPause()
    }
}

@Composable
private fun RoundAction(
    icon: ImageVector, label: String, active: Boolean = false, enabled: Boolean = true, onClick: () -> Unit
) {
    val c = LocalColors.current
    val g = LocalGlass.current
    Column(
        Modifier.width(96.dp).bounce(enabled = enabled, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        val bg = when {
            active -> Modifier.clip(CircleShape).background(c.accent.copy(alpha = 0.28f))
            g != GlassStyle.SOLID -> Modifier.glass(CircleShape)
            else -> Modifier
        }
        Box(Modifier.size(64.dp).then(bg), contentAlignment = Alignment.Center) {
            Icon(
                icon, null, Modifier.size(28.dp),
                tint = (if (active) c.accent else c.text).copy(alpha = if (enabled) 1f else 0.35f)
            )
        }
        Spacer(Modifier.height(6.dp))
        Text(
            label, color = if (active) c.accent else c.sub.copy(alpha = if (enabled) 1f else 0.5f),
            fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1,
            overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun BigButton(color: Color, icon: ImageVector, desc: String, pulse: Boolean = false, onClick: () -> Unit) {
    val t = rememberInfiniteTransition(label = "pulse")
    val s by t.animateFloat(
        initialValue = 1f, targetValue = if (pulse) 1.12f else 1f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "s"
    )
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(76.dp).scale(s).bounce(onClick = onClick).clip(CircleShape).background(color),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, Modifier.size(34.dp), tint = Color.White) }
        Spacer(Modifier.height(8.dp))
        Text(desc, color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp)
    }
}

@Composable
private fun SmallRound(icon: ImageVector, active: Boolean, onClick: () -> Unit) {
    val c = LocalColors.current
    Box(
        Modifier.size(56.dp).bounce(onClick = onClick).then(
            if (active) Modifier.clip(CircleShape).background(c.accent.copy(alpha = 0.28f))
            else Modifier.glass(CircleShape)
        ),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, Modifier.size(26.dp), tint = if (active) c.accent else c.text) }
}

@Composable
fun InCallScreen(onFinish: () -> Unit) {
    val ctx = LocalContext.current
    val c = LocalColors.current
    val infos by CallManager.calls.collectAsState()
    val muted by CallManager.muted.collectAsState()
    val route by CallManager.route.collectAsState()
    val mask by CallManager.routeMask.collectAsState()
    var last by remember { mutableStateOf<CallManager.Info?>(null) }
    var showKeys by remember { mutableStateOf(false) }
    var typed by remember { mutableStateOf("") }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    val primary = infos.firstOrNull { it.state == Call.STATE_RINGING } ?: infos.firstOrNull()
    LaunchedEffect(primary) { if (primary != null) last = primary }
    LaunchedEffect(infos.isEmpty()) {
        if (infos.isEmpty()) {
            delay(1000)
            onFinish()
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(500)
        }
    }

    val shown = primary ?: last
    if (shown != null) {
        val ended = primary == null
        val number = shown.number
        val contact by produceState(Pair<String?, String?>(null, null), number) {
            value = Repo.lookup(ctx, number)
        }
        val name = contact.first ?: shown.name?.takeIf { it.isNotBlank() }
        val title = name ?: if (number.isBlank()) stringResource(R.string.private_number) else prettyNumber(number)
        val elapsed = if (shown.connectMs > 0) ((now - shown.connectMs) / 1000).coerceAtLeast(0) else 0L
        val ringing = !ended && shown.state == Call.STATE_RINGING
        val holding = !ended && shown.state == Call.STATE_HOLDING
        val label = when {
            ended -> stringResource(R.string.call_ended)
            shown.state == Call.STATE_RINGING -> stringResource(R.string.incoming_call)
            shown.state == Call.STATE_ACTIVE -> fmtTime(elapsed)
            holding -> stringResource(R.string.on_hold)
            shown.state == Call.STATE_DISCONNECTED || shown.state == Call.STATE_DISCONNECTING ->
                stringResource(R.string.call_ended)
            else -> stringResource(R.string.calling)
        }
        val others = infos.filter { it.call !== shown.call }
        val btAvail = (mask and CallAudioState.ROUTE_BLUETOOTH) != 0

        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(36.dp))
            Avatar(name, contact.second, 132.dp)
            Spacer(Modifier.height(18.dp))
            Text(
                title, color = c.text, fontSize = 30.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
            )
            if (name != null && number.isNotBlank()) {
                Text(prettyNumber(number), color = c.sub, fontSize = 16.sp)
            }
            Spacer(Modifier.height(10.dp))
            Text(
                label, color = c.text,
                fontSize = if (shown.state == Call.STATE_ACTIVE && !ended) 52.sp else 26.sp,
                fontWeight = FontWeight.Bold
            )

            if (others.isNotEmpty() && !ended) {
                Spacer(Modifier.height(14.dp))
                others.forEach { o ->
                    Row(
                        Modifier.fillMaxWidth().glass(RoundedCornerShape(20.dp)).padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                if (!o.name.isNullOrBlank()) o.name else prettyNumber(o.number),
                                color = c.text, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                            Text(stringResource(R.string.call_waiting), color = c.sub, fontSize = 12.sp)
                        }
                        Text(
                            stringResource(R.string.switch_call), color = c.accent, fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.tap {
                                CallManager.hold(shown.call, true)
                                CallManager.hold(o.call, false)
                            }.padding(8.dp)
                        )
                    }
                }
            }

            Spacer(Modifier.weight(1f))

            if (ringing) {
                Row(Modifier.fillMaxWidth().padding(bottom = 36.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    BigButton(c.danger, Ic.callEnd, stringResource(R.string.decline)) { CallManager.reject(shown.call) }
                    BigButton(c.accent, Ic.call, stringResource(R.string.answer), pulse = true) { CallManager.answer(shown.call) }
                }
            } else {
                if (!showKeys) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        RoundAction(Ic.message, stringResource(R.string.message), enabled = !ended && number.isNotBlank()) {
                            safeStart(ctx, smsIntent(number))
                        }
                        RoundAction(
                            Ic.bluetooth, stringResource(R.string.audio),
                            active = route == CallAudioState.ROUTE_BLUETOOTH, enabled = btAvail && !ended
                        ) {
                            CallManager.setRoute(
                                if (route == CallAudioState.ROUTE_BLUETOOTH) CallAudioState.ROUTE_WIRED_OR_EARPIECE
                                else CallAudioState.ROUTE_BLUETOOTH
                            )
                        }
                        RoundAction(Ic.contacts, stringResource(R.string.contacts), enabled = !ended) {
                            safeStart(ctx, Intent(ctx, MainActivity::class.java).putExtra("tab", 1))
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        RoundAction(
                            if (muted) Ic.micOff else Ic.mic,
                            stringResource(if (muted) R.string.unmute else R.string.mute),
                            active = muted, enabled = !ended
                        ) { CallManager.setMuted(!muted) }
                        RoundAction(
                            if (holding) Ic.play else Ic.pause,
                            stringResource(if (holding) R.string.resume else R.string.hold),
                            active = holding, enabled = !ended
                        ) { CallManager.hold(shown.call, !holding) }
                        RoundAction(Ic.add, stringResource(R.string.add_call), enabled = !ended) {
                            safeStart(ctx, Intent(Intent.ACTION_DIAL).setClass(ctx, MainActivity::class.java))
                        }
                    }
                } else {
                    Column(
                        Modifier.fillMaxWidth().glass(RoundedCornerShape(32.dp)).padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            typed, color = c.accent, fontSize = 26.sp, fontWeight = FontWeight.Medium,
                            maxLines = 1, modifier = Modifier.height(40.dp)
                        )
                        KeyGrid(onKey = { ch ->
                            typed += ch
                            CallManager.dtmf(shown.call, ch)
                        })
                    }
                }
                Spacer(Modifier.height(22.dp))
                Row(
                    Modifier.fillMaxWidth().padding(bottom = 18.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.width(96.dp), contentAlignment = Alignment.Center) {
                        SmallRound(Ic.volumeUp, route == CallAudioState.ROUTE_SPEAKER) {
                            CallManager.setRoute(
                                if (route == CallAudioState.ROUTE_SPEAKER) CallAudioState.ROUTE_WIRED_OR_EARPIECE
                                else CallAudioState.ROUTE_SPEAKER
                            )
                        }
                    }
                    Box(
                        Modifier.size(76.dp).bounce { CallManager.hangup(shown.call) }
                            .clip(CircleShape).background(c.danger),
                        contentAlignment = Alignment.Center
                    ) { Icon(Ic.callEnd, stringResource(R.string.end_call), Modifier.size(34.dp), tint = Color.White) }
                    Box(Modifier.width(96.dp), contentAlignment = Alignment.Center) {
                        SmallRound(Ic.dialpad, showKeys) { showKeys = !showKeys }
                    }
                }
            }
        }
    }
}
