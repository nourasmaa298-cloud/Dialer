package app.glassdialer

import android.Manifest
import android.content.Context
import android.net.Uri
import android.provider.CallLog
import android.provider.CallLog.Calls as Calls
import android.provider.ContactsContract.CommonDataKinds.Phone as Phone
import android.provider.ContactsContract
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class CallEntry(
    val id: Long,
    val number: String,
    val name: String?,
    val photo: String?,
    val type: Int,
    val date: Long,
    val duration: Long,
    val count: Int = 1
)

data class ContactEntry(val id: Long, val name: String, val number: String, val photo: String?)

object Repo {
    fun norm(n: String): String = n.filter { it.isDigit() }.takeLast(9)

    suspend fun contacts(ctx: Context): List<ContactEntry> = withContext(Dispatchers.IO) {
        val out = ArrayList<ContactEntry>()
        if (!ctx.has(Manifest.permission.READ_CONTACTS)) return@withContext out
        val seen = HashSet<String>()
        try {
            ctx.contentResolver.query(
                Phone.CONTENT_URI,
                arrayOf(Phone.CONTACT_ID, Phone.DISPLAY_NAME, Phone.NUMBER, Phone.PHOTO_THUMBNAIL_URI),
                null, null,
                Phone.DISPLAY_NAME + " COLLATE LOCALIZED ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    val name = c.getString(1) ?: continue
                    val num = c.getString(2) ?: continue
                    if (!seen.add(id.toString() + ":" + norm(num))) continue
                    out.add(ContactEntry(id, name, num, c.getString(3)))
                }
            }
        } catch (_: Throwable) {
        }
        out
    }

    suspend fun calls(ctx: Context, byNum: Map<String, ContactEntry>): List<CallEntry> = withContext(Dispatchers.IO) {
        val raw = ArrayList<CallEntry>()
        if (!ctx.has(Manifest.permission.READ_CALL_LOG)) return@withContext raw
        try {
            ctx.contentResolver.query(
                Calls.CONTENT_URI,
                arrayOf(Calls._ID, Calls.NUMBER, Calls.CACHED_NAME, Calls.TYPE, Calls.DATE, Calls.DURATION),
                null, null, Calls.DATE + " DESC"
            )?.use { c ->
                var n = 0
                while (c.moveToNext() && n < 400) {
                    var num = c.getString(1) ?: ""
                    if (num == "-1" || num == "-2") num = ""
                    val hit = byNum[norm(num)]
                    val cached = c.getString(2)
                    raw.add(
                        CallEntry(
                            id = c.getLong(0),
                            number = num,
                            name = if (!cached.isNullOrBlank()) cached else hit?.name,
                            photo = hit?.photo,
                            type = c.getInt(3),
                            date = c.getLong(4),
                            duration = c.getLong(5)
                        )
                    )
                    n++
                }
            }
        } catch (_: Throwable) {
        }
        val out = ArrayList<CallEntry>()
        for (e in raw) {
            val last = out.lastOrNull()
            if (last != null && last.number == e.number && last.type == e.type) {
                out[out.size - 1] = last.copy(count = last.count + 1)
            } else out.add(e)
        }
        out
    }

    suspend fun lookup(ctx: Context, number: String): Pair<String?, String?> = withContext(Dispatchers.IO) {
        var result: Pair<String?, String?> = Pair(null, null)
        if (number.isNotBlank() && ctx.has(Manifest.permission.READ_CONTACTS)) {
            try {
                val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
                ctx.contentResolver.query(
                    uri,
                    arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME, ContactsContract.PhoneLookup.PHOTO_THUMBNAIL_URI),
                    null, null, null
                )?.use { c ->
                    if (c.moveToFirst()) result = Pair(c.getString(0), c.getString(1))
                }
            } catch (_: Throwable) {
            }
        }
        result
    }

    fun deleteNumber(ctx: Context, number: String) {
        try {
            ctx.contentResolver.delete(CallLog.Calls.CONTENT_URI, CallLog.Calls.NUMBER + "=?", arrayOf(number))
        } catch (_: Throwable) {
        }
    }
}
