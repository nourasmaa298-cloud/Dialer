package app.glassdialer

import android.app.Application

class DialerApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
    }
}
