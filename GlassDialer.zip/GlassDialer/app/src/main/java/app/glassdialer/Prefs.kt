package app.glassdialer

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.os.LocaleListCompat

enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class GlassStyle { SOLID, GLASS, FROSTED, LIQUID }
enum class Accent(val argb: Long) {
    GREEN(0xFF22C55E), BLUE(0xFF3B82F6), PURPLE(0xFF8B5CF6), ORANGE(0xFFF97316)
}

object Prefs {
    private var sp: SharedPreferences? = null

    var themeMode by mutableStateOf(ThemeMode.SYSTEM)
        private set
    var glass by mutableStateOf(GlassStyle.SOLID)
        private set
    var accent by mutableStateOf(Accent.GREEN)
        private set
    var tones by mutableStateOf(true)
        private set
    var haptics by mutableStateOf(true)
        private set
    var defaultSim by mutableStateOf(-1)
        private set
    var lang by mutableStateOf("")
        private set

    fun init(ctx: Context) {
        val p = ctx.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)
        sp = p
        themeMode = runCatching { ThemeMode.valueOf(p.getString("theme", "SYSTEM") ?: "SYSTEM") }.getOrDefault(ThemeMode.SYSTEM)
        glass = runCatching { GlassStyle.valueOf(p.getString("glass", "SOLID") ?: "SOLID") }.getOrDefault(GlassStyle.SOLID)
        accent = runCatching { Accent.valueOf(p.getString("accent", "GREEN") ?: "GREEN") }.getOrDefault(Accent.GREEN)
        tones = p.getBoolean("tones", true)
        haptics = p.getBoolean("haptics", true)
        defaultSim = p.getInt("defaultSim", -1)
        lang = p.getString("lang", "") ?: ""
    }

    fun setThemeMode(v: ThemeMode) { themeMode = v; sp?.edit()?.putString("theme", v.name)?.apply() }
    fun setGlass(v: GlassStyle) { glass = v; sp?.edit()?.putString("glass", v.name)?.apply() }
    fun setAccent(v: Accent) { accent = v; sp?.edit()?.putString("accent", v.name)?.apply() }
    fun setTones(v: Boolean) { tones = v; sp?.edit()?.putBoolean("tones", v)?.apply() }
    fun setHaptics(v: Boolean) { haptics = v; sp?.edit()?.putBoolean("haptics", v)?.apply() }
    fun setDefaultSim(v: Int) { defaultSim = v; sp?.edit()?.putInt("defaultSim", v)?.apply() }

    fun setLang(tag: String) {
        lang = tag
        sp?.edit()?.putString("lang", tag)?.apply()
        AppCompatDelegate.setApplicationLocales(
            if (tag.isEmpty()) LocaleListCompat.getEmptyLocaleList()
            else LocaleListCompat.forLanguageTags(tag)
        )
    }
}
