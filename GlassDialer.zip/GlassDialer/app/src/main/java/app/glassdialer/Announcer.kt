package app.glassdialer

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Speaks the caller's name (or "unknown caller") once when a call starts ringing. */
object CallerAnnouncer {
    @Volatile private var tts: TextToSpeech? = null
    @Volatile private var ready = false
    private var pending: (() -> Unit)? = null

    private fun localeFor(tag: String): Locale = when (tag) {
        "ar" -> Locale("ar")
        "tr" -> Locale("tr")
        "en" -> Locale.US
        else -> Locale.getDefault()
    }

    private fun ensure(ctx: Context) {
        if (tts != null) return
        val app = ctx.applicationContext
        tts = TextToSpeech(app) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) {
                try {
                    tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {}
                        override fun onDone(utteranceId: String?) {}
                        override fun onError(utteranceId: String?) {}
                    })
                } catch (_: Throwable) {
                }
                pending?.invoke()
                pending = null
            }
        }
    }

    fun announce(ctx: Context, name: String?, number: String) {
        if (!Prefs.callerIdSpeak) return
        ensure(ctx)
        val run = {
            try {
                val t = tts ?: return@run
                val locale = localeFor(Prefs.lang)
                val res = t.setLanguage(locale)
                if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                    t.setLanguage(Locale.US)
                }
                val phrase = if (!name.isNullOrBlank()) {
                    ctx.getString(R.string.cid_announce_known, name)
                } else if (number.isNotBlank()) {
                    ctx.getString(R.string.cid_announce_number, spaceOutDigits(number))
                } else {
                    ctx.getString(R.string.cid_announce_unknown)
                }
                val params = Bundle()
                params.putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, android.media.AudioManager.STREAM_RING)
                t.speak(phrase, TextToSpeech.QUEUE_FLUSH, params, "cid_" + System.currentTimeMillis())
            } catch (_: Throwable) {
            }
        }
        if (ready) run() else pending = run
    }

    private fun spaceOutDigits(n: String): String = n.toCharArray().joinToString(" ")

    fun stop() {
        try {
            tts?.stop()
        } catch (_: Throwable) {
        }
    }

    fun shutdown() {
        try {
            tts?.shutdown()
        } catch (_: Throwable) {
        }
        tts = null
        ready = false
    }
}
