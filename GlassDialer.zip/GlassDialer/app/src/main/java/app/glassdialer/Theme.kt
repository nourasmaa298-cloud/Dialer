package app.glassdialer

import android.app.Activity
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat

class AppColors(
    val dark: Boolean,
    val bg: Color,
    val surface: Color,
    val surfaceHigh: Color,
    val text: Color,
    val sub: Color,
    val accent: Color,
    val link: Color,
    val danger: Color
)

val LocalColors = staticCompositionLocalOf<AppColors> { error("AppTheme missing") }
val LocalGlass = staticCompositionLocalOf { GlassStyle.SOLID }

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val dark = when (Prefs.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val accent = Color(Prefs.accent.argb)
    val colors = remember(dark, accent) {
        if (dark) AppColors(
            true, Color(0xFF000000), Color(0xFF2A2A2C), Color(0xFF3A3A3D), Color(0xFFFFFFFF),
            Color(0xFF9A9AA0), accent, Color(0xFF4C8DFF), Color(0xFFE5342F)
        ) else AppColors(
            false, Color(0xFFF2F2F7), Color(0xFFFFFFFF), Color(0xFFE9E9EE), Color(0xFF111114),
            Color(0xFF6B6B73), accent, Color(0xFF2563EB), Color(0xFFD92D20)
        )
    }
    val view = LocalView.current
    SideEffect {
        val w = (view.context as? Activity)?.window
        if (w != null) {
            val ctl = WindowCompat.getInsetsController(w, view)
            ctl.isAppearanceLightStatusBars = !dark
            ctl.isAppearanceLightNavigationBars = !dark
        }
    }
    CompositionLocalProvider(
        LocalColors provides colors,
        LocalGlass provides Prefs.glass,
        LocalContentColor provides colors.text
    ) { content() }
}

private fun DrawScope.blob(color: Color, cx: Float, cy: Float, r: Float) {
    drawCircle(
        brush = Brush.radialGradient(listOf(color, Color.Transparent), center = Offset(cx, cy), radius = r),
        radius = r,
        center = Offset(cx, cy)
    )
}

@Composable
private fun Blobs() {
    val c = LocalColors.current
    val t = rememberInfiniteTransition(label = "blobs")
    val p = t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(16000, easing = LinearEasing), RepeatMode.Reverse),
        label = "p"
    )
    Canvas(Modifier.fillMaxSize()) {
        val a = if (c.dark) 0.38f else 0.45f
        val w = size.width
        val h = size.height
        val v = p.value
        blob(c.accent.copy(alpha = a), w * (0.15f + 0.4f * v), h * 0.20f, w * 0.85f)
        blob(Color(0xFF7C3AED).copy(alpha = a), w * (0.9f - 0.4f * v), h * 0.55f, w * 0.8f)
        blob(Color(0xFF0EA5E9).copy(alpha = a), w * (0.2f + 0.3f * v), h * 0.95f, w * 0.85f)
    }
}

@Composable
fun AppBackground(content: @Composable BoxScope.() -> Unit) {
    val c = LocalColors.current
    val g = LocalGlass.current
    Box(Modifier.fillMaxSize().background(c.bg)) {
        if (g != GlassStyle.SOLID) Blobs()
        content()
    }
}

/** The one surface modifier: its look depends on the selected style (solid / glass / frosted / liquid). */
fun Modifier.glass(shape: Shape = RoundedCornerShape(28.dp)): Modifier = composed {
    val c = LocalColors.current
    when (LocalGlass.current) {
        GlassStyle.SOLID -> this.clip(shape).background(c.surface)

        GlassStyle.GLASS -> this.clip(shape)
            .background(if (c.dark) Color.White.copy(alpha = 0.10f) else Color.White.copy(alpha = 0.55f))
            .border(
                1.dp,
                Brush.linearGradient(
                    listOf(Color.White.copy(alpha = if (c.dark) 0.35f else 0.9f), Color.White.copy(alpha = 0.05f))
                ),
                shape
            )

        GlassStyle.FROSTED -> this.clip(shape)
            .background(if (c.dark) Color(0xFF3A3A3F).copy(alpha = 0.62f) else Color.White.copy(alpha = 0.72f))
            .border(1.dp, Color.White.copy(alpha = if (c.dark) 0.12f else 0.6f), shape)

        GlassStyle.LIQUID -> {
            val t = rememberInfiniteTransition(label = "liquid")
            val s = t.animateFloat(
                initialValue = 0f, targetValue = 1f,
                animationSpec = infiniteRepeatable(tween(7000, easing = LinearEasing), RepeatMode.Reverse),
                label = "s"
            )
            this.clip(shape)
                .background(
                    Brush.verticalGradient(
                        if (c.dark) listOf(Color.White.copy(alpha = 0.20f), Color.White.copy(alpha = 0.06f))
                        else listOf(Color.White.copy(alpha = 0.75f), Color.White.copy(alpha = 0.35f))
                    )
                )
                .drawBehind {
                    val cx = size.width * (0.1f + 0.8f * s.value)
                    val r = size.maxDimension * 0.75f
                    blob(Color.White.copy(alpha = if (c.dark) 0.28f else 0.6f), cx, 0f, r)
                    blob(c.accent.copy(alpha = 0.22f), size.width - cx, size.height, r * 0.7f)
                }
                .border(
                    1.2.dp,
                    Brush.linearGradient(
                        listOf(Color.White.copy(alpha = 0.9f), Color.White.copy(alpha = 0.08f), Color.White.copy(alpha = 0.5f))
                    ),
                    shape
                )
        }
    }
}
