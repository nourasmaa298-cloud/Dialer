package app.glassdialer

import android.app.Activity
import android.os.Build
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.roundToInt
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

class AppColors(
    val dark: Boolean,
    val bg: Color,
    val surface: Color,
    val surfaceHigh: Color,
    val text: Color,
    val sub: Color,
    val accent: Color,
    val link: Color,
    val danger: Color
)

val LocalColors = staticCompositionLocalOf<AppColors> { error("AppTheme missing") }
val LocalGlass = staticCompositionLocalOf { GlassStyle.SOLID }

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val dark = when (Prefs.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val amoled = Prefs.amoled
    val accent = if (Prefs.accent == Accent.DYNAMIC && Build.VERSION.SDK_INT >= 31) {
        Color(ctx.getColor(android.R.color.system_accent1_500))
    } else Color(Prefs.accent.argb)

    val colors = remember(dark, accent, amoled) {
        if (dark) {
            if (amoled) AppColors(
                true, Color(0xFF000000), Color(0xFF2A2A2C), Color(0xFF3A3A3D), Color(0xFFFFFFFF),
                Color(0xFF9A9AA0), accent, Color(0xFF4C8DFF), Color(0xFFE5342F)
            ) else AppColors(
                true, Color(0xFF16161A), Color(0xFF26262B), Color(0xFF34343A), Color(0xFFFFFFFF),
                Color(0xFFA0A0A8), accent, Color(0xFF4C8DFF), Color(0xFFE5342F)
            )
        } else AppColors(
            false, Color(0xFFF2F2F7), Color(0xFFFFFFFF), Color(0xFFE9E9EE), Color(0xFF111114),
            Color(0xFF6B6B73), accent, Color(0xFF2563EB), Color(0xFFD92D20)
        )
    }
    val view = LocalView.current
    SideEffect {
        val w = (view.context as? Activity)?.window
        if (w != null) {
            val ctl = WindowCompat.getInsetsController(w, view)
            ctl.isAppearanceLightStatusBars = !dark
            ctl.isAppearanceLightNavigationBars = !dark
        }
    }
    val d = LocalDensity.current
    val scale = Prefs.textScale
    val dens = remember(d, scale) { Density(d.density, d.fontScale * (scale / 100f)) }
    CompositionLocalProvider(
        LocalDensity provides dens,
        LocalColors provides colors,
        LocalGlass provides Prefs.glass,
        LocalContentColor provides colors.text
    ) { content() }
}

fun DrawScope.blob(color: Color, cx: Float, cy: Float, r: Float) {
    drawCircle(
        brush = Brush.radialGradient(listOf(color, Color.Transparent), center = Offset(cx, cy), radius = r),
        radius = r,
        center = Offset(cx, cy)
    )
}

fun DrawScope.drawAurora(area: Size, ph: Float, colors: List<Color>, alpha: Float) {
    val w = area.width
    val h = area.height
    colors.forEachIndexed { i, col ->
        val off = i * 1.7f
        val ky = 1 + (i % 2)
        val cx = w * (0.5f + 0.45f * cos(ph + off))
        val cy = h * (0.5f + 0.40f * sin(ph * ky + off))
        blob(col.copy(alpha = alpha), cx, cy, w * (0.7f + 0.08f * i))
    }
}

/** Slowly drifting colour blobs. */
@Composable
fun Aurora(colors: List<Color>, alpha: Float) {
    val t = rememberInfiniteTransition(label = "aurora")
    val p by t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(26000, easing = LinearEasing), RepeatMode.Restart),
        label = "p"
    )
    val motion = Prefs.motion
    Canvas(Modifier.fillMaxSize()) {
        val ph = if (motion) p * 2f * PI.toFloat() else 0.8f
        drawAurora(size, ph, colors, alpha)
    }
}

/** Everything painted behind the UI. Glass panels paint the same thing (extra blurred) under their own tint. */
class BackdropSpec(
    val bg: Color,
    val aurora: List<Color>?,
    val auroraAlpha: Float,
    val image: ImageBitmap?,
    val panelImage: ImageBitmap?,
    val dim: Float,
    val phase: State<Float>,
    val motion: Boolean
)

class BackdropHolder(val spec: BackdropSpec, val size: State<Size>)

val LocalBackdrop = staticCompositionLocalOf<BackdropHolder?> { null }

private fun DrawScope.drawCropped(img: ImageBitmap, area: Size, dim: Float) {
    val iw = img.width.toFloat()
    val ih = img.height.toFloat()
    val sc = max(area.width / iw, area.height / ih)
    val dw = iw * sc
    val dh = ih * sc
    val dx = (area.width - dw) / 2f
    val dy = (area.height - dh) / 2f
    drawImage(
        image = img,
        dstOffset = IntOffset(dx.roundToInt(), dy.roundToInt()),
        dstSize = IntSize(dw.roundToInt(), dh.roundToInt()),
        filterQuality = FilterQuality.High
    )
    if (dim > 0f) drawRect(Color.Black.copy(alpha = dim), size = area)
}

fun DrawScope.paintBackdrop(spec: BackdropSpec, area: Size, forPanel: Boolean) {
    drawRect(spec.bg, size = area)
    val colors = spec.aurora
    if (colors != null) {
        val ph = if (spec.motion) spec.phase.value * 2f * PI.toFloat() else 0.8f
        drawAurora(area, ph, colors, spec.auroraAlpha)
    }
    val img = if (forPanel) (spec.panelImage ?: spec.image) else spec.image
    if (img != null) drawCropped(img, area, spec.dim)
}

@Composable
fun AppBackground(content: @Composable BoxScope.() -> Unit) {
    val ctx = LocalContext.current
    val c = LocalColors.current
    val mode = Prefs.appBg
    val uri = Prefs.bgImage
    val blur = Prefs.bgBlur
    val dimPct = Prefs.bgDim
    val motion = Prefs.motion
    val imgs by produceState<Pair<ImageBitmap, ImageBitmap>?>(null, mode, uri, blur) {
        value = if (mode == AppBg.IMAGE && uri.isNotEmpty()) {
            val b = loadBackground(ctx, uri)
            if (b != null) {
                withContext(Dispatchers.Default) {
                    Pair(blurBitmap(b, blur).asImageBitmap(), blurBitmap(b, 100).asImageBitmap())
                }
            } else null
        } else null
    }
    val t = rememberInfiniteTransition(label = "bg")
    val phase = t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(26000, easing = LinearEasing), RepeatMode.Restart),
        label = "phase"
    )
    val rootSize = remember { mutableStateOf(Size.Zero) }
    val pair = imgs
    val spec = remember(c.bg, c.accent, c.dark, mode, pair, dimPct, motion) {
        BackdropSpec(
            bg = c.bg,
            aurora = if (mode == AppBg.AURORA) {
                listOf(c.accent, Color(0xFF7C3AED), Color(0xFF0EA5E9), Color(0xFFEC4899))
            } else null,
            auroraAlpha = if (c.dark) 0.34f else 0.42f,
            image = pair?.first,
            panelImage = pair?.second,
            dim = dimPct / 100f,
            phase = phase,
            motion = motion
        )
    }
    val holder = remember(spec) { BackdropHolder(spec, rootSize) }
    Box(
        Modifier.fillMaxSize().onSizeChanged { rootSize.value = Size(it.width.toFloat(), it.height.toFloat()) }
    ) {
        Canvas(Modifier.fillMaxSize()) { paintBackdrop(spec, size, false) }
        CompositionLocalProvider(LocalBackdrop provides holder) { content() }
    }
}

/**
 * The one surface modifier. Non-solid styles paint the (extra blurred) backdrop opaquely under a tint,
 * so nothing behind the panel (list rows, text...) can show through.
 */
fun Modifier.glass(shape: Shape = RoundedCornerShape(28.dp)): Modifier = composed {
    val c = LocalColors.current
    val style = LocalGlass.current
    val bd = LocalBackdrop.current
    val k = Prefs.glassStrength / 100f
    fun a(x: Float): Float = (x * k).coerceIn(0f, 1f)
    val pos = remember { mutableStateOf(Offset.Zero) }

    if (style == GlassStyle.SOLID) {
        this.clip(shape).background(c.surface)
    } else {
        val base: Modifier = if (bd != null) {
            this.onGloballyPositioned { pos.value = it.positionInRoot() }
                .clip(shape)
                .drawBehind {
                    val p = pos.value
                    translate(-p.x, -p.y) { paintBackdrop(bd.spec, bd.size.value, true) }
                }
        } else {
            this.clip(shape).background(c.surface)
        }
        when (style) {
            GlassStyle.GLASS -> base
                .background(if (c.dark) Color.White.copy(alpha = a(0.12f)) else Color.White.copy(alpha = a(0.45f)))
                .border(
                    1.dp,
                    Brush.linearGradient(
                        listOf(Color.White.copy(alpha = a(if (c.dark) 0.35f else 0.9f)), Color.White.copy(alpha = a(0.05f)))
                    ),
                    shape
                )

            GlassStyle.FROSTED -> base
                .background(if (c.dark) Color(0xFF3A3A3F).copy(alpha = a(0.45f)) else Color.White.copy(alpha = a(0.62f)))
                .border(1.dp, Color.White.copy(alpha = a(if (c.dark) 0.12f else 0.6f)), shape)

            else -> {
                val t = rememberInfiniteTransition(label = "liquid")
                val s = t.animateFloat(
                    initialValue = 0f, targetValue = 1f,
                    animationSpec = infiniteRepeatable(tween(7000, easing = LinearEasing), RepeatMode.Reverse),
                    label = "s"
                )
                base
                    .background(
                        Brush.verticalGradient(
                            if (c.dark) listOf(Color.White.copy(alpha = a(0.18f)), Color.White.copy(alpha = a(0.05f)))
                            else listOf(Color.White.copy(alpha = a(0.6f)), Color.White.copy(alpha = a(0.28f)))
                        )
                    )
                    .drawBehind {
                        val cx = size.width * (0.1f + 0.8f * s.value)
                        val r = size.maxDimension * 0.75f
                        blob(Color.White.copy(alpha = if (c.dark) a(0.28f) else a(0.6f)), cx, 0f, r)
                        blob(c.accent.copy(alpha = 0.22f), size.width - cx, size.height, r * 0.7f)
                    }
                    .border(
                        1.2.dp,
                        Brush.linearGradient(
                            listOf(Color.White.copy(alpha = a(0.9f)), Color.White.copy(alpha = a(0.08f)), Color.White.copy(alpha = a(0.5f)))
                        ),
                        shape
                    )
            }
        }
    }
}

/** Translucent white surface used on top of the blurred call backdrop (always light-on-dark). */
fun Modifier.callGlass(shape: Shape): Modifier = composed {
    val g = LocalGlass.current
    val k = Prefs.glassStrength / 100f
    val base0 = when (g) {
        GlassStyle.SOLID -> 0.16f
        GlassStyle.GLASS -> 0.18f
        GlassStyle.FROSTED -> 0.26f
        GlassStyle.LIQUID -> 0.20f
    }
    val base = (base0 * k).coerceIn(0f, 0.6f)
    val m = this.clip(shape)
        .background(Color.White.copy(alpha = base))
        .border(
            1.dp,
            Brush.linearGradient(
                listOf(Color.White.copy(alpha = 0.55f), Color.White.copy(alpha = 0.08f), Color.White.copy(alpha = 0.3f))
            ),
            shape
        )
    if (g == GlassStyle.LIQUID) {
        m.drawBehind { blob(Color.White.copy(alpha = 0.25f), size.width * 0.3f, 0f, size.maxDimension * 0.8f) }
    } else m
}
