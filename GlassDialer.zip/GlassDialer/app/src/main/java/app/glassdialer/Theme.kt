package app.glassdialer

import android.app.Activity
import android.os.Build
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

class AppColors(
    val dark: Boolean,
    val bg: Color,
    val surface: Color,
    val surfaceHigh: Color,
    val text: Color,
    val sub: Color,
    val accent: Color,
    val link: Color,
    val danger: Color
)

val LocalColors = staticCompositionLocalOf<AppColors> { error("AppTheme missing") }
val LocalGlass = staticCompositionLocalOf { GlassStyle.SOLID }

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val dark = when (Prefs.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val amoled = Prefs.amoled
    val accent = if (Prefs.accent == Accent.DYNAMIC && Build.VERSION.SDK_INT >= 31) {
        Color(ctx.getColor(android.R.color.system_accent1_500))
    } else Color(Prefs.accent.argb)

    val colors = remember(dark, accent, amoled) {
        if (dark) {
            if (amoled) AppColors(
                true, Color(0xFF000000), Color(0xFF2A2A2C), Color(0xFF3A3A3D), Color(0xFFFFFFFF),
                Color(0xFF9A9AA0), accent, Color(0xFF4C8DFF), Color(0xFFE5342F)
            ) else AppColors(
                true, Color(0xFF16161A), Color(0xFF26262B), Color(0xFF34343A), Color(0xFFFFFFFF),
                Color(0xFFA0A0A8), accent, Color(0xFF4C8DFF), Color(0xFFE5342F)
            )
        } else AppColors(
            false, Color(0xFFF2F2F7), Color(0xFFFFFFFF), Color(0xFFE9E9EE), Color(0xFF111114),
            Color(0xFF6B6B73), accent, Color(0xFF2563EB), Color(0xFFD92D20)
        )
    }
    val view = LocalView.current
    SideEffect {
        val w = (view.context as? Activity)?.window
        if (w != null) {
            val ctl = WindowCompat.getInsetsController(w, view)
            ctl.isAppearanceLightStatusBars = !dark
            ctl.isAppearanceLightNavigationBars = !dark
        }
    }
    val d = LocalDensity.current
    val scale = Prefs.textScale
    val dens = remember(d, scale) { Density(d.density, d.fontScale * (scale / 100f)) }
    CompositionLocalProvider(
        LocalDensity provides dens,
        LocalColors provides colors,
        LocalGlass provides Prefs.glass,
        LocalContentColor provides colors.text
    ) { content() }
}

fun DrawScope.blob(color: Color, cx: Float, cy: Float, r: Float) {
    drawCircle(
        brush = Brush.radialGradient(listOf(color, Color.Transparent), center = Offset(cx, cy), radius = r),
        radius = r,
        center = Offset(cx, cy)
    )
}

fun DrawScope.drawAurora(area: Size, ph: Float, colors: List<Color>, alpha: Float) {
    val w = area.width
    val h = area.height
    colors.forEachIndexed { i, col ->
        val off = i * 1.7f
        val ky = 1 + (i % 2)
        val cx = w * (0.5f + 0.45f * cos(ph + off))
        val cy = h * (0.5f + 0.40f * sin(ph * ky + off))
        blob(col.copy(alpha = alpha), cx, cy, w * (0.7f + 0.08f * i))
    }
}

/** Slowly drifting colour blobs (used by the call screen). */
@Composable
fun Aurora(colors: List<Color>, alpha: Float) {
    val t = rememberInfiniteTransition(label = "aurora")
    val p by t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(26000, easing = LinearEasing), RepeatMode.Restart),
        label = "p"
    )
    val motion = Prefs.motion
    Canvas(Modifier.fillMaxSize()) {
        val ph = if (motion) p * 2f * PI.toFloat() else 0.8f
        drawAurora(size, ph, colors, alpha)
    }
}

/** What the app background looks like. */
class BackdropSpec(
    val bg: Color,
    val aurora: List<Color>?,
    val auroraAlpha: Float,
    val image: ImageBitmap?,
    val dim: Float,
    val phase: State<Float>,
    val motion: Boolean
)

private fun DrawScope.drawCropped(img: ImageBitmap, area: Size, dim: Float) {
    val iw = img.width.toFloat()
    val ih = img.height.toFloat()
    val sc = max(area.width / iw, area.height / ih)
    val dw = iw * sc
    val dh = ih * sc
    val dx = (area.width - dw) / 2f
    val dy = (area.height - dh) / 2f
    drawImage(
        image = img,
        dstOffset = IntOffset(dx.roundToInt(), dy.roundToInt()),
        dstSize = IntSize(dw.roundToInt(), dh.roundToInt()),
        filterQuality = FilterQuality.High
    )
    if (dim > 0f) drawRect(Color.Black.copy(alpha = dim), size = area)
}

fun DrawScope.paintBackdrop(spec: BackdropSpec, area: Size) {
    drawRect(spec.bg, size = area)
    val colors = spec.aurora
    if (colors != null) {
        val ph = if (spec.motion) spec.phase.value * 2f * PI.toFloat() else 0.8f
        drawAurora(area, ph, colors, spec.auroraAlpha)
    }
    val img = spec.image
    if (img != null) drawCropped(img, area, spec.dim)
}

/**
 * Paints the app background into a GraphicsLayer. Glass panels later draw that layer (blurred)
 * under themselves, which is what makes the blur real.
 */
@Composable
fun AppBackground(content: @Composable BoxScope.() -> Unit) {
    val ctx = LocalContext.current
    val c = LocalColors.current
    val mode = Prefs.appBg
    val uri = Prefs.bgImage
    val blur = Prefs.bgBlur
    val dimPct = Prefs.bgDim
    val motion = Prefs.motion
    val img by produceState<ImageBitmap?>(null, mode, uri, blur) {
        value = if (mode == AppBg.IMAGE && uri.isNotEmpty()) {
            val b = loadBackground(ctx, uri)
            if (b != null) {
                withContext(Dispatchers.Default) { blurBitmap(b, blur).asImageBitmap() }
            } else null
        } else null
    }
    val t = rememberInfiniteTransition(label = "bg")
    val phase = t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(26000, easing = LinearEasing), RepeatMode.Restart),
        label = "phase"
    )
    val layer = rememberGraphicsLayer()
    val source = remember(layer) { BackdropSource(layer) }
    val image = img
    val spec = remember(c.bg, c.accent, c.dark, mode, image, dimPct, motion) {
        BackdropSpec(
            bg = c.bg,
            aurora = if (mode == AppBg.AURORA) {
                listOf(c.accent, Color(0xFF7C3AED), Color(0xFF0EA5E9), Color(0xFFEC4899))
            } else null,
            auroraAlpha = if (c.dark) 0.34f else 0.42f,
            image = image,
            dim = dimPct / 100f,
            phase = phase,
            motion = motion
        )
    }
    Box(Modifier.fillMaxSize()) {
        Box(
            Modifier.fillMaxSize()
                .backdropSource(layer)
                .drawBehind { paintBackdrop(spec, size) }
        )
        CompositionLocalProvider(LocalBackdrop provides source) { content() }
    }
}

/**
 * The one surface modifier.
 *  - Solid : plain opaque surface.
 *  - Blur  : real backdrop blur of whatever is drawn behind the panel (Android 12+).
 *  - Liquid: blur + lens refraction/dispersion at the edges + flowing highlights (refraction needs Android 13+).
 */
fun Modifier.glass(shape: Shape = RoundedCornerShape(28.dp)): Modifier = composed {
    val c = LocalColors.current
    val style = LocalGlass.current
    val src = LocalBackdrop.current
    if (style == GlassStyle.SOLID) {
        this.clip(shape).background(c.surface)
    } else if (src == null || Build.VERSION.SDK_INT < 31) {
        this.clip(shape)
            .background(c.surface.copy(alpha = 0.88f))
            .border(1.dp, Color.White.copy(alpha = 0.14f), shape)
    } else {
        this.glassBlur(src, shape, style == GlassStyle.LIQUID)
    }
}

/** Translucent white surface used on top of the blurred call backdrop (always light-on-dark). */
fun Modifier.callGlass(shape: Shape): Modifier = composed {
    val g = LocalGlass.current
    val base = when (g) {
        GlassStyle.SOLID -> 0.16f
        GlassStyle.BLUR -> 0.20f
        GlassStyle.LIQUID -> 0.20f
    }
    val m = this.clip(shape)
        .background(Color.White.copy(alpha = base))
        .border(
            1.dp,
            Brush.linearGradient(
                listOf(Color.White.copy(alpha = 0.55f), Color.White.copy(alpha = 0.08f), Color.White.copy(alpha = 0.3f))
            ),
            shape
        )
    if (g == GlassStyle.LIQUID) {
        m.drawBehind { blob(Color.White.copy(alpha = 0.25f), size.width * 0.3f, 0f, size.maxDimension * 0.8f) }
    } else m
}
