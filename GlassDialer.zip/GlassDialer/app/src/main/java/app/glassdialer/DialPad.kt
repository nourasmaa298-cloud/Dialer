package app.glassdialer

import android.telecom.PhoneAccountHandle
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val KEYS = listOf(
    "1" to "", "2" to "ABC", "3" to "DEF",
    "4" to "GHI", "5" to "JKL", "6" to "MNO",
    "7" to "PQRS", "8" to "TUV", "9" to "WXYZ",
    "*" to "", "0" to "+", "#" to ""
)

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun Key(
    digit: Char, letters: String, modifier: Modifier, tint: Color?,
    onPress: (Char) -> Unit, onLong: (() -> Unit)? = null
) {
    val c = LocalColors.current
    val fg = tint ?: c.text
    val sub = if (tint != null) tint.copy(alpha = 0.6f) else c.sub
    val circle = Prefs.keyStyle == KeyStyle.CIRCLE
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed) 0.86f else 1f,
        spring(dampingRatio = 0.45f, stiffness = 500f),
        label = "key"
    )
    val hl by animateFloatAsState(
        if (pressed) 0.22f else if (circle) 0.09f else 0f,
        tween(120), label = "keybg"
    )
    Box(modifier.height(70.dp), contentAlignment = Alignment.Center) {
        Column(
            (if (circle) Modifier.size(64.dp) else Modifier.fillMaxWidth().height(62.dp))
                .scale(scale)
                .clip(if (circle) CircleShape else RoundedCornerShape(22.dp))
                .background(fg.copy(alpha = hl))
                .combinedClickable(
                    interactionSource = src, indication = null,
                    onClick = { onPress(digit) }, onLongClick = onLong
                ),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(digit.toString(), color = fg, fontSize = 28.sp, fontWeight = FontWeight.Light)
            if (Prefs.showLetters) {
                Text(letters, color = sub, fontSize = 9.sp, letterSpacing = 1.sp, modifier = Modifier.height(11.dp))
            }
        }
    }
}

@Composable
fun KeyGrid(onKey: (Char) -> Unit, modifier: Modifier = Modifier, tint: Color? = null) {
    val haptic = LocalHapticFeedback.current
    Column(modifier) {
        KEYS.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth()) {
                row.forEach { (d, l) ->
                    Key(
                        d[0], l, Modifier.weight(1f), tint,
                        onPress = { ch ->
                            if (Prefs.haptics) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            if (Prefs.tones) Tones.play(ch)
                            onKey(ch)
                        },
                        onLong = if (d == "0") ({
                            if (Prefs.haptics) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            onKey('+')
                        }) else null
                    )
                }
            }
        }
    }
}

@Composable
private fun CallPill(label: String, shape: RoundedCornerShape, modifier: Modifier, onClick: () -> Unit) {
    val c = LocalColors.current
    Row(
        modifier.height(48.dp).bounce(onClick = onClick).clip(shape).background(c.accent).padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Ic.call, null, Modifier.size(18.dp), tint = Color.White)
        Spacer(Modifier.width(6.dp))
        Text(
            label, color = Color.White, fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DialPadCard(
    number: String,
    suggestion: String?,
    sims: List<SimAccount>,
    onKey: (Char) -> Unit,
    onDelete: () -> Unit,
    onClear: () -> Unit,
    onCall: (PhoneAccountHandle?) -> Unit
) {
    val c = LocalColors.current
    Column(
        Modifier.fillMaxWidth().widthIn(max = 440.dp)
            .glass(RoundedCornerShape(32.dp)).padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Row(Modifier.fillMaxWidth().height(56.dp), verticalAlignment = Alignment.CenterVertically) {
            Spacer(Modifier.size(34.dp))
            Column(
                Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    prettyNumber(number), color = c.accent,
                    fontSize = if (number.length > 12) 22.sp else 28.sp,
                    fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                if (suggestion != null) {
                    Text(suggestion, color = c.sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            Box(
                Modifier.size(34.dp).combinedClickable(
                    interactionSource = remember { MutableInteractionSource() }, indication = null,
                    enabled = number.isNotEmpty(), onClick = onDelete, onLongClick = onClear
                ),
                contentAlignment = Alignment.Center
            ) {
                if (number.isNotEmpty()) Icon(Ic.backspace, null, Modifier.size(22.dp), tint = c.sub)
            }
        }
        KeyGrid(onKey)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth()) {
            if (sims.size >= 2) {
                CallPill(
                    sims[0].label, RoundedCornerShape(topStart = 24.dp, bottomStart = 24.dp, topEnd = 6.dp, bottomEnd = 6.dp),
                    Modifier.weight(1f)
                ) { onCall(sims[0].handle) }
                Spacer(Modifier.width(2.dp))
                CallPill(
                    sims[1].label, RoundedCornerShape(topStart = 6.dp, bottomStart = 6.dp, topEnd = 24.dp, bottomEnd = 24.dp),
                    Modifier.weight(1f)
                ) { onCall(sims[1].handle) }
            } else {
                CallPill(stringResource(R.string.call), RoundedCornerShape(24.dp), Modifier.weight(1f)) {
                    onCall(sims.firstOrNull()?.handle)
                }
            }
        }
    }
}
