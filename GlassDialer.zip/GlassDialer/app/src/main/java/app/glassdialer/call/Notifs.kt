package app.glassdialer.call

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import app.glassdialer.InCallActivity
import app.glassdialer.R

object Notifs {
    private const val CH = "incoming_calls"
    private const val ID = 4101

    fun showIncoming(ctx: Context, name: String?, number: String) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CH, ctx.getString(R.string.incoming_call), NotificationManager.IMPORTANCE_HIGH)
            ch.setSound(null, null)
            ch.enableVibration(false)
            ch.setShowBadge(false)
            nm.createNotificationChannel(ch)
        }
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(
            ctx, 1, Intent(ctx, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), flags
        )
        val answer = PendingIntent.getBroadcast(
            ctx, 2, Intent(ctx, CallActionReceiver::class.java).setAction(CallActionReceiver.ACTION_ANSWER), flags
        )
        val decline = PendingIntent.getBroadcast(
            ctx, 3, Intent(ctx, CallActionReceiver::class.java).setAction(CallActionReceiver.ACTION_DECLINE), flags
        )
        val title = if (!name.isNullOrBlank()) name else if (number.isNotBlank()) number else ctx.getString(R.string.unknown)
        val n = NotificationCompat.Builder(ctx, CH)
            .setSmallIcon(R.drawable.ic_call)
            .setContentTitle(title)
            .setContentText(ctx.getString(R.string.incoming_call))
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setOngoing(true)
            .setFullScreenIntent(open, true)
            .setContentIntent(open)
            .addAction(0, ctx.getString(R.string.decline), decline)
            .addAction(0, ctx.getString(R.string.answer), answer)
            .build()
        try {
            nm.notify(ID, n)
        } catch (_: SecurityException) {
        }
    }

    fun cancel(ctx: Context) {
        (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(ID)
    }
}
