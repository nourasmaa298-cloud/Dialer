package app.glassdialer

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.telecom.TelecomManager
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInParent
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@Composable
fun Banner(title: String, desc: String, button: String, onClick: () -> Unit) {
    val c = LocalColors.current
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
            .glass(RoundedCornerShape(22.dp)).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = c.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text(desc, color = c.sub, fontSize = 13.sp)
        }
        Spacer(Modifier.width(12.dp))
        Box(
            Modifier.bounce(onClick = onClick).clip(RoundedCornerShape(16.dp)).background(c.accent)
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) { Text(button, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
    }
}

@Composable
fun RecentsList(
    calls: List<CallEntry>,
    top: @Composable () -> Unit,
    bottomPad: Dp,
    onCall: (String) -> Unit,
    onInfo: (CallEntry) -> Unit
) {
    val ctx = LocalContext.current
    val c = LocalColors.current
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = bottomPad)) {
        item { top() }
        if (calls.isEmpty()) item { EmptyState(stringResource(R.string.no_calls)) }
        itemsIndexed(calls, key = { _, e -> e.id }) { i, e ->
            val missed = e.type == 3 || e.type == 5
            val base = e.name ?: if (e.number.isBlank()) stringResource(R.string.private_number) else prettyNumber(e.number)
            val title = if (e.count > 1) base + " (" + e.count + ")" else base
            val typeIcon = when (e.type) {
                1 -> Ic.received
                3, 5 -> Ic.missed
                else -> Ic.made
            }
            Row(
                Modifier.fillMaxWidth().enterAnim(i).tap { onCall(e.number) }
                    .padding(horizontal = 20.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Avatar(e.name, e.photo, 46.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        title, color = if (missed) c.danger else c.text, fontSize = 17.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(typeIcon, null, Modifier.size(14.dp), tint = if (missed) c.danger else c.sub)
                        Spacer(Modifier.width(4.dp))
                        Text(
                            if (e.name != null) prettyNumber(e.number) else fmtDate(ctx, e.date),
                            color = c.sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                if (e.name != null) {
                    Text(fmtDate(ctx, e.date), color = c.sub, fontSize = 13.sp)
                }
                Box(Modifier.size(40.dp).tap { onInfo(e) }, contentAlignment = Alignment.Center) {
                    Icon(Ic.info, null, Modifier.size(22.dp), tint = c.sub)
                }
            }
        }
    }
}

@Composable
fun ContactsList(
    contacts: List<ContactEntry>,
    query: String,
    onQuery: (String) -> Unit,
    bottomPad: Dp,
    onCall: (String) -> Unit
) {
    val c = LocalColors.current
    val filtered = remember(contacts, query) {
        if (query.isBlank()) contacts
        else {
            val qd = query.filter { it.isDigit() }.ifEmpty { "\u0000" }
            contacts.filter { it.name.contains(query, ignoreCase = true) || it.number.filter { ch -> ch.isDigit() }.contains(qd) }
        }
    }
    Column(Modifier.fillMaxSize()) {
        BasicTextField(
            value = query, onValueChange = onQuery, singleLine = true,
            textStyle = TextStyle(color = c.text, fontSize = 16.sp),
            cursorBrush = SolidColor(c.accent),
            decorationBox = { inner ->
                Row(Modifier.fillMaxHeight(), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Ic.search, null, Modifier.size(20.dp), tint = c.sub)
                    Spacer(Modifier.width(10.dp))
                    Box(Modifier.weight(1f)) {
                        if (query.isEmpty()) Text(stringResource(R.string.search_contacts), color = c.sub, fontSize = 16.sp)
                        inner()
                    }
                }
            },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp).height(52.dp)
                .glass(RoundedCornerShape(26.dp)).padding(horizontal = 16.dp)
        )
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = bottomPad)) {
            if (filtered.isEmpty()) item { EmptyState(stringResource(R.string.no_contacts)) }
            itemsIndexed(filtered, key = { _, e -> e.id.toString() + ":" + Repo.norm(e.number) }) { i, e ->
                val letter = e.name.firstOrNull { it.isLetter() }?.uppercaseChar() ?: '#'
                val prev = if (i > 0) filtered[i - 1].name.firstOrNull { it.isLetter() }?.uppercaseChar() ?: '#' else null
                Column(Modifier.fillMaxWidth().enterAnim(i)) {
                    if (prev != letter) {
                        Text(
                            letter.toString(), color = c.accent, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(start = 24.dp, top = 12.dp, bottom = 2.dp)
                        )
                    }
                    Row(
                        Modifier.fillMaxWidth().tap { onCall(e.number) }.padding(horizontal = 20.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Avatar(e.name, e.photo, 44.dp)
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text(e.name, color = c.text, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(prettyNumber(e.number), color = c.sub, fontSize = 13.sp, maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}

private class Act(val label: String, val icon: ImageVector, val color: Color, val run: () -> Unit)

@Composable
fun DetailScreen(
    number: String,
    name: String?,
    photo: String?,
    history: List<CallEntry>,
    onBack: () -> Unit,
    onCall: () -> Unit,
    onVideo: () -> Unit,
    onDeleted: () -> Unit
) {
    val ctx = LocalContext.current
    val c = LocalColors.current
    val noteText = remember(number) { Prefs.note(number) }
    val acts = ArrayList<Act>()
    acts.add(Act(stringResource(R.string.call), Ic.call, c.link, onCall))
    if (name == null) {
        acts.add(Act(stringResource(R.string.new_contact), Ic.personAdd, c.link) { safeStart(ctx, newContactIntent(number)) })
        acts.add(Act(stringResource(R.string.add_to_contacts), Ic.add, c.link) { safeStart(ctx, addToContactIntent(number)) })
    }
    acts.add(Act(stringResource(R.string.video_call), Ic.videocam, c.link, onVideo))
    acts.add(Act(stringResource(R.string.send_message), Ic.message, c.link) { safeStart(ctx, smsIntent(number)) })
    acts.add(Act(stringResource(R.string.delete_entry), Ic.delete, c.danger) {
        Repo.deleteNumber(ctx, number)
        onDeleted()
    })

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        TopBar(stringResource(R.string.recents) + "  |  " + prettyNumber(number), onBack)
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 32.dp)) {
            item {
                Column(
                    Modifier.fillMaxWidth().enterAnim(0).padding(vertical = 18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Avatar(name, photo, 96.dp)
                    Spacer(Modifier.height(12.dp))
                    Text(name ?: prettyNumber(number), color = c.text, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
                    if (name != null) Text(prettyNumber(number), color = c.sub, fontSize = 15.sp)
                }
            }
            if (noteText.isNotEmpty()) {
                item {
                    Row(
                        Modifier.fillMaxWidth().enterAnim(1).glass(RoundedCornerShape(24.dp)).padding(16.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(Ic.note, null, Modifier.size(20.dp), tint = c.sub)
                        Spacer(Modifier.width(12.dp))
                        Text(noteText, color = c.text, fontSize = 15.sp)
                    }
                    Spacer(Modifier.height(12.dp))
                }
            }
            item {
                Column(Modifier.fillMaxWidth().enterAnim(2).glass(RoundedCornerShape(24.dp))) {
                    acts.forEach { a ->
                        Row(
                            Modifier.fillMaxWidth().tap { a.run() }.padding(horizontal = 18.dp, vertical = 15.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(a.icon, null, Modifier.size(22.dp), tint = a.color)
                            Spacer(Modifier.width(14.dp))
                            Text(a.label, color = a.color, fontSize = 17.sp)
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(16.dp)) }
            items(history, key = { it.id }) { e ->
                val ctx2 = LocalContext.current
                Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    val missed = e.type == 3 || e.type == 5
                    Icon(
                        when (e.type) {
                            1 -> Ic.received
                            3, 5 -> Ic.missed
                            else -> Ic.made
                        },
                        null, Modifier.size(18.dp), tint = if (missed) c.danger else c.sub
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(fmtDate(ctx2, e.date), color = c.text, fontSize = 15.sp, modifier = Modifier.weight(1f))
                    if (e.duration > 0) Text(fmtTime(e.duration), color = c.sub, fontSize = 14.sp)
                }
            }
        }
    }
}

@Composable
fun <T> ChipGroup(options: List<Pair<String, T>>, selected: T, perRow: Int = 2, onSelect: (T) -> Unit) {
    val c = LocalColors.current
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        options.chunked(perRow).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { (label, v) ->
                    val sel = v == selected
                    Box(
                        Modifier.weight(1f).height(44.dp).bounce { onSelect(v) }
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (sel) c.accent else c.text.copy(alpha = 0.08f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            label, color = if (sel) Color.White else c.text, fontSize = 14.sp,
                            fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                repeat(perRow - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
private fun SettingsCard(title: String, index: Int, content: @Composable () -> Unit) {
    val c = LocalColors.current
    Column(
        Modifier.fillMaxWidth().enterAnim(index).glass(RoundedCornerShape(24.dp)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(title, color = c.sub, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        content()
    }
}

@Composable
private fun SubLabel(text: String) {
    Text(text, color = LocalColors.current.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
}

@Composable
private fun SwitchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val c = LocalColors.current
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = c.text, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = c.accent, checkedThumbColor = Color.White)
        )
    }
}

@Composable
private fun SliderRow(label: String, value: Int, min: Int, max: Int, suffix: String = "", onChange: (Int) -> Unit) {
    val c = LocalColors.current
    Column {
        Row(Modifier.fillMaxWidth()) {
            Text(label, color = c.text, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            Text(value.toString() + suffix, color = c.sub, fontSize = 14.sp)
        }
        Slider(
            value = value.toFloat(),
            onValueChange = { onChange(it.roundToInt()) },
            valueRange = min.toFloat()..max.toFloat(),
            colors = SliderDefaults.colors(
                thumbColor = c.accent, activeTrackColor = c.accent,
                inactiveTrackColor = c.text.copy(alpha = 0.15f)
            )
        )
    }
}

@Composable
private fun PillButton(text: String, onClick: () -> Unit) {
    val c = LocalColors.current
    Box(
        Modifier.bounce(onClick = onClick).clip(RoundedCornerShape(16.dp)).background(c.accent)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) { Text(text, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
}

@Composable
fun SettingsScreen(
    sims: List<SimAccount>,
    isDefault: Boolean,
    onRequestDefault: () -> Unit,
    onPickImage: () -> Unit,
    onImportPhotos: () -> Unit,
    onBack: () -> Unit
) {
    val ctx = LocalContext.current
    val c = LocalColors.current
    val version = remember {
        runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "1.0"
    }
    var crash by remember { mutableStateOf(Prefs.lastCrash()) }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        TopBar(stringResource(R.string.settings), onBack)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            SettingsCard(stringResource(R.string.default_dialer), 0) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        stringResource(if (isDefault) R.string.status_yes else R.string.status_no),
                        color = if (isDefault) c.accent else c.sub, fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)
                    )
                    if (!isDefault) PillButton(stringResource(R.string.set_default), onRequestDefault)
                }
            }

            SettingsCard(stringResource(R.string.appearance), 1) {
                SubLabel(stringResource(R.string.theme_mode))
                ChipGroup(
                    listOf(
                        stringResource(R.string.mode_system) to ThemeMode.SYSTEM,
                        stringResource(R.string.mode_light) to ThemeMode.LIGHT,
                        stringResource(R.string.mode_dark) to ThemeMode.DARK
                    ),
                    Prefs.themeMode, 3
                ) { Prefs.updateThemeMode(it) }
                SwitchRow(stringResource(R.string.amoled), Prefs.amoled) { Prefs.updateAmoled(it) }
                SubLabel(stringResource(R.string.style))
                ChipGroup(
                    listOf(
                        stringResource(R.string.style_solid) to GlassStyle.SOLID,
                        stringResource(R.string.style_blur) to GlassStyle.BLUR,
                        stringResource(R.string.style_liquid) to GlassStyle.LIQUID
                    ),
                    Prefs.glass, 3
                ) {
                    Prefs.updateGlass(it)
                    if (it != GlassStyle.SOLID && Prefs.appBg == AppBg.SOLID) Prefs.updateAppBg(AppBg.AURORA)
                }
                SubLabel(stringResource(R.string.accent))
                val accents = Accent.values().filter { it != Accent.DYNAMIC || Build.VERSION.SDK_INT >= 31 }
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    accents.chunked(4).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            row.forEach { a ->
                                val dot = if (a == Accent.DYNAMIC) {
                                    Modifier.size(42.dp).bounce { Prefs.updateAccent(a) }.clip(CircleShape).background(
                                        Brush.sweepGradient(
                                            listOf(
                                                Color(0xFFEF4444), Color(0xFFF59E0B), Color(0xFF22C55E),
                                                Color(0xFF0EA5E9), Color(0xFF8B5CF6), Color(0xFFEF4444)
                                            )
                                        )
                                    )
                                } else {
                                    Modifier.size(42.dp).bounce { Prefs.updateAccent(a) }.clip(CircleShape)
                                        .background(Color(a.argb))
                                }
                                Box(dot, contentAlignment = Alignment.Center) {
                                    if (Prefs.accent == a) Icon(Ic.check, null, Modifier.size(22.dp), tint = Color.White)
                                }
                            }
                        }
                    }
                }
                SliderRow(stringResource(R.string.text_size), Prefs.textScale, 80, 130, "%") { Prefs.updateTextScale(it) }
            }

            SettingsCard(stringResource(R.string.backgrounds), 2) {
                SubLabel(stringResource(R.string.bg_mode))
                ChipGroup(
                    listOf(
                        stringResource(R.string.bg_solid) to AppBg.SOLID,
                        stringResource(R.string.bg_aurora) to AppBg.AURORA,
                        stringResource(R.string.bg_image) to AppBg.IMAGE
                    ),
                    Prefs.appBg, 3
                ) { Prefs.updateAppBg(it) }
                PillButton(stringResource(R.string.pick_image), onPickImage)
                if (Prefs.appBg == AppBg.IMAGE) {
                    SliderRow(stringResource(R.string.blur), Prefs.bgBlur, 0, 100) { Prefs.updateBgBlur(it) }
                    SliderRow(stringResource(R.string.dim), Prefs.bgDim, 0, 80, "%") { Prefs.updateBgDim(it) }
                }
            }

            SettingsCard(stringResource(R.string.call_screen), 3) {
                SubLabel(stringResource(R.string.call_bg))
                ChipGroup(
                    listOf(
                        stringResource(R.string.cbg_wallpaper) to CallBg.WALLPAPER,
                        stringResource(R.string.cbg_photo) to CallBg.PHOTO,
                        stringResource(R.string.cbg_aurora) to CallBg.AURORA,
                        stringResource(R.string.cbg_solid) to CallBg.SOLID
                    ),
                    Prefs.callBg, 2
                ) { Prefs.updateCallBg(it) }
                if (Prefs.callBg == CallBg.WALLPAPER) {
                    Text(stringResource(R.string.blur_unavailable), color = c.sub, fontSize = 12.sp)
                }
                if (Prefs.callBg == CallBg.WALLPAPER || Prefs.callBg == CallBg.PHOTO) {
                    SliderRow(stringResource(R.string.blur), Prefs.callBlur, 0, 100) { Prefs.updateCallBlur(it) }
                }
                SliderRow(stringResource(R.string.dim), Prefs.callDim, 0, 80, "%") { Prefs.updateCallDim(it) }
                SwitchRow(stringResource(R.string.show_avatar), Prefs.showAvatar) { Prefs.updateShowAvatar(it) }
            }

            SettingsCard(stringResource(R.string.dialpad_section), 4) {
                SubLabel(stringResource(R.string.key_style))
                ChipGroup(
                    listOf(
                        stringResource(R.string.key_plain) to KeyStyle.PLAIN,
                        stringResource(R.string.key_circle) to KeyStyle.CIRCLE
                    ),
                    Prefs.keyStyle, 2
                ) { Prefs.updateKeyStyle(it) }
                SwitchRow(stringResource(R.string.show_letters), Prefs.showLetters) { Prefs.updateShowLetters(it) }
                SwitchRow(stringResource(R.string.dtmf_tones), Prefs.tones) { Prefs.updateTones(it) }
                SwitchRow(stringResource(R.string.haptics), Prefs.haptics) { Prefs.updateHaptics(it) }
            }

            SettingsCard(stringResource(R.string.import_photos), 5) {
                Text(stringResource(R.string.import_photos_desc), color = c.sub, fontSize = 13.sp)
                PillButton(stringResource(R.string.import_photos_btn), onImportPhotos)
            }

            SettingsCard(stringResource(R.string.language), 5) {
                ChipGroup(
                    listOf(
                        stringResource(R.string.lang_system) to "",
                        "English" to "en",
                        "العربية" to "ar",
                        "Türkçe" to "tr"
                    ),
                    Prefs.lang, 2
                ) { Prefs.updateLang(it) }
            }

            SettingsCard(stringResource(R.string.calls_section), 6) {
                if (sims.size > 1) {
                    SubLabel(stringResource(R.string.default_sim))
                    ChipGroup(
                        listOf(
                            stringResource(R.string.sim_ask) to -1,
                            sims[0].label to 0,
                            sims[1].label to 1
                        ),
                        Prefs.defaultSim, 3
                    ) { Prefs.updateDefaultSim(it) }
                }
                Text(
                    stringResource(R.string.blocked_numbers), color = c.link, fontSize = 16.sp,
                    modifier = Modifier.fillMaxWidth().tap {
                        try {
                            val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
                            safeStart(ctx, tm.createManageBlockedNumbersIntent())
                        } catch (_: Throwable) {
                        }
                    }.padding(vertical = 6.dp)
                )
            }

            SettingsCard(stringResource(R.string.general), 7) {
                SwitchRow(stringResource(R.string.animations), Prefs.motion) { Prefs.updateMotion(it) }
            }

            SettingsCard(stringResource(R.string.about), 8) {
                Text(stringResource(R.string.app_name), color = c.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Text(stringResource(R.string.version, version), color = c.sub, fontSize = 14.sp)
            }

            if (crash.isNotEmpty()) {
                SettingsCard(stringResource(R.string.crash_title), 9) {
                    Text(crash.take(500), color = c.sub, fontSize = 11.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        PillButton(stringResource(R.string.copy)) {
                            try {
                                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cm.setPrimaryClip(ClipData.newPlainText("crash", Prefs.lastCrash()))
                            } catch (_: Throwable) {
                            }
                        }
                        PillButton(stringResource(R.string.clear)) {
                            Prefs.clearCrash()
                            crash = ""
                        }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun NavItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    modifier: Modifier,
    onPress: (Boolean) -> Unit,
    onClick: () -> Unit
) {
    val c = LocalColors.current
    val pop by animateFloatAsState(
        if (selected) 1.14f else 1f,
        spring(dampingRatio = 0.4f, stiffness = 380f),
        label = "navPop"
    )
    Column(
        modifier.width(92.dp)
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        onPress(true)
                        tryAwaitRelease()
                        onPress(false)
                    },
                    onTap = { onClick() }
                )
            }
            .padding(vertical = 7.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            icon, null,
            Modifier.size(24.dp).graphicsLayer { scaleX = pop; scaleY = pop },
            tint = if (selected) c.text else c.sub
        )
        Text(label, color = if (selected) c.text else c.sub, fontSize = 11.sp, maxLines = 1, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun BottomNav(tab: Int, onTab: (Int) -> Unit, padOpen: Boolean, onPad: () -> Unit) {
    val c = LocalColors.current
    val density = LocalDensity.current
    val itemX = remember { mutableStateListOf(0f, 0f) }
    val itemW = remember { mutableStateListOf(0f, 0f) }
    var itemH by remember { mutableStateOf(0f) }
    var pressed by remember { mutableStateOf(false) }
    val left = remember { Animatable(0f) }
    val right = remember { Animatable(0f) }
    val measured = itemW[0] > 0f && itemW[1] > 0f && itemH > 0f

    // The selection capsule glides to the chosen tab; its leading edge runs ahead of the trailing edge,
    // so it stretches while travelling and settles with a little wobble.
    LaunchedEffect(tab, measured, itemX[0], itemX[1], itemW[0], itemW[1]) {
        if (measured) {
            val tl = itemX[tab]
            val tr = tl + itemW[tab]
            if (left.value == 0f && right.value == 0f) {
                left.snapTo(tl)
                right.snapTo(tr)
            } else {
                val goingRight = tl > left.value
                launch { left.animateTo(tl, spring(dampingRatio = 0.62f, stiffness = if (goingRight) 170f else 700f)) }
                launch { right.animateTo(tr, spring(dampingRatio = 0.62f, stiffness = if (goingRight) 700f else 170f)) }
            }
        }
    }
    val press by animateFloatAsState(
        if (pressed) 0.86f else 1f,
        spring(dampingRatio = 0.45f, stiffness = 420f),
        label = "navPress"
    )

    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(Modifier.glass(RoundedCornerShape(32.dp)).padding(6.dp)) {
            if (measured) {
                Box(
                    Modifier.offset { IntOffset(left.value.roundToInt(), 0) }
                        .width(with(density) { (right.value - left.value).coerceAtLeast(0f).toDp() })
                        .height(with(density) { itemH.toDp() })
                        .graphicsLayer {
                            scaleX = press
                            scaleY = press
                        }
                        .clip(RoundedCornerShape(26.dp))
                        .background(c.text.copy(alpha = 0.15f))
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                NavItem(
                    Ic.history, stringResource(R.string.recents), tab == 0,
                    Modifier.onGloballyPositioned {
                        itemX[0] = it.positionInParent().x
                        itemW[0] = it.size.width.toFloat()
                        itemH = it.size.height.toFloat()
                    },
                    { pressed = it }
                ) { onTab(0) }
                NavItem(
                    Ic.contactPerson, stringResource(R.string.contacts), tab == 1,
                    Modifier.onGloballyPositioned {
                        itemX[1] = it.positionInParent().x
                        itemW[1] = it.size.width.toFloat()
                    },
                    { pressed = it }
                ) { onTab(1) }
            }
        }
        Box(
            Modifier.size(60.dp).bounce(onClick = onPad).then(
                if (padOpen) Modifier.glass(CircleShape) else Modifier.clip(CircleShape).background(c.accent)
            ),
            contentAlignment = Alignment.Center
        ) {
            Crossfade(targetState = padOpen, label = "fab") { open ->
                Icon(
                    if (open) Ic.keyboardDown else Ic.dialpad, null, Modifier.size(26.dp),
                    tint = if (open) c.text else Color.White
                )
            }
        }
    }
}
