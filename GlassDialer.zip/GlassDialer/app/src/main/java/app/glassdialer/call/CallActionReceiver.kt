package app.glassdialer.call

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telecom.Call
import app.glassdialer.InCallActivity

class CallActionReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val ringing = CallManager.calls.value.firstOrNull { it.state == Call.STATE_RINGING } ?: return
        when (intent.action) {
            ACTION_ANSWER -> {
                CallManager.answer(ringing.call)
                ctx.startActivity(Intent(ctx, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            ACTION_DECLINE -> CallManager.reject(ringing.call)
        }
        Notifs.cancel(ctx)
    }

    companion object {
        const val ACTION_ANSWER = "app.glassdialer.ANSWER"
        const val ACTION_DECLINE = "app.glassdialer.DECLINE"
    }
}
