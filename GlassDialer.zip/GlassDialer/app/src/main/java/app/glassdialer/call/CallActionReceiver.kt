package app.glassdialer.call

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telecom.Call

class CallActionReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        when (intent.action) {
            ACTION_DECLINE -> {
                CallManager.calls.value.firstOrNull { it.state == Call.STATE_RINGING }
                    ?.let { CallManager.reject(it.call) }
                Notifs.cancel(ctx)
            }
            ACTION_HANGUP -> {
                CallManager.calls.value.firstOrNull { it.state != Call.STATE_RINGING }
                    ?.let { CallManager.hangup(it.call) }
            }
        }
    }

    companion object {
        const val ACTION_DECLINE = "app.glassdialer.DECLINE"
        const val ACTION_HANGUP = "app.glassdialer.HANGUP"
    }
}
