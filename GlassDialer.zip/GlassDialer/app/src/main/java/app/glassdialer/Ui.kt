package app.glassdialer

import android.content.Context
import android.net.Uri
import android.text.format.DateFormat
import android.text.format.DateUtils
import android.util.LruCache
import android.graphics.BitmapFactory
import android.graphics.Bitmap
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.CallMade
import androidx.compose.material.icons.filled.CallMissed
import androidx.compose.material.icons.filled.CallReceived
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Date

/** All icons in one place so other files never import icon names that clash with telecom classes. */
object Ic {
    val call = Icons.Filled.Call
    val callEnd = Icons.Filled.CallEnd
    val backspace = Icons.Filled.Backspace
    val back = Icons.AutoMirrored.Filled.ArrowBack
    val settings = Icons.Filled.Settings
    val dialpad = Icons.Filled.Dialpad
    val history = Icons.Filled.History
    val contacts = Icons.Filled.Contacts
    val person = Icons.Filled.Person
    val personAdd = Icons.Filled.PersonAdd
    val videocam = Icons.Filled.Videocam
    val message = Icons.Filled.Message
    val search = Icons.Filled.Search
    val mic = Icons.Filled.Mic
    val micOff = Icons.Filled.MicOff
    val volumeUp = Icons.Filled.VolumeUp
    val pause = Icons.Filled.Pause
    val play = Icons.Filled.PlayArrow
    val add = Icons.Filled.Add
    val bluetooth = Icons.Filled.Bluetooth
    val made = Icons.Filled.CallMade
    val received = Icons.Filled.CallReceived
    val missed = Icons.Filled.CallMissed
    val delete = Icons.Filled.Delete
    val info = Icons.Outlined.Info
    val check = Icons.Filled.Check
    val note = Icons.Filled.Description
    val keyboardDown = Icons.Filled.KeyboardArrowDown
}

/** Plain click without any indication. */
fun Modifier.tap(enabled: Boolean = true, onClick: () -> Unit): Modifier = composed {
    clickable(
        enabled = enabled,
        interactionSource = remember { MutableInteractionSource() },
        indication = null,
        onClick = onClick
    )
}

/** Click with a small spring-like press scale. Put it BEFORE clip/background in the chain. */
fun Modifier.bounce(enabled: Boolean = true, onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(
        if (pressed) 0.9f else 1f,
        spring(dampingRatio = 0.45f, stiffness = 500f),
        label = "bounce"
    )
    this.scale(s).clickable(enabled = enabled, interactionSource = src, indication = null, onClick = onClick)
}

object PhotoCache {
    private val cache = LruCache<String, ImageBitmap>(80)

    suspend fun load(ctx: Context, uri: String): ImageBitmap? = withContext(Dispatchers.IO) {
        cache.get(uri) ?: try {
            ctx.contentResolver.openInputStream(Uri.parse(uri))?.use { s ->
                BitmapFactory.decodeStream(s)?.asImageBitmap()
            }?.also { cache.put(uri, it) }
        } catch (_: Throwable) {
            null
        }
    }
}

private val avatarColors = listOf(0xFF3B82F6, 0xFF22C55E, 0xFFF59E0B, 0xFFEF4444, 0xFF8B5CF6, 0xFF14B8A6, 0xFFEC4899)

@Composable
fun Avatar(name: String?, photo: String?, size: Dp, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, photo) {
        value = if (photo == null) null else PhotoCache.load(ctx, photo)
    }
    val idx = ((name ?: "").hashCode() and Int.MAX_VALUE) % avatarColors.size
    Box(
        modifier.size(size).clip(CircleShape).background(Color(avatarColors[idx]).copy(alpha = 0.85f)),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            Image(bitmap = b, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else {
            val initial = name?.trim()?.firstOrNull { it.isLetter() }
            if (initial != null) {
                Text(initial.uppercase(), color = Color.White, fontSize = (size.value * 0.4f).sp, fontWeight = FontWeight.Medium)
            } else {
                Icon(Ic.person, null, Modifier.size(size * 0.55f), tint = Color.White)
            }
        }
    }
}

@Composable
fun TopBar(title: String, onBack: (() -> Unit)? = null, trailing: @Composable RowScope.() -> Unit = {}) {
    val c = LocalColors.current
    Row(
        Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            Box(Modifier.size(44.dp).tap(onClick = onBack), contentAlignment = Alignment.Center) {
                Icon(Ic.back, null, tint = c.text)
            }
        } else Spacer(Modifier.width(8.dp))
        Text(
            title, color = c.text, fontSize = 24.sp, fontWeight = FontWeight.SemiBold,
            maxLines = 1, modifier = Modifier.weight(1f).padding(horizontal = 6.dp)
        )
        trailing()
    }
}

@Composable
fun EmptyState(text: String) {
    val c = LocalColors.current
    Box(Modifier.fillMaxWidth().padding(top = 80.dp), contentAlignment = Alignment.Center) {
        Text(text, color = c.sub, fontSize = 16.sp)
    }
}

fun fmtDate(ctx: Context, ms: Long): String = when {
    DateUtils.isToday(ms) -> DateFormat.getTimeFormat(ctx).format(Date(ms))
    DateUtils.isToday(ms + DateUtils.DAY_IN_MILLIS) -> ctx.getString(R.string.yesterday)
    else -> DateFormat.getDateFormat(ctx).format(Date(ms))
}

/** Fade + slide-up when an item first appears. */
fun Modifier.enterAnim(index: Int = 0): Modifier = composed {
    if (!Prefs.motion) {
        this
    } else {
        val a = remember { Animatable(0f) }
        LaunchedEffect(Unit) {
            a.animateTo(1f, tween(380, delayMillis = index.coerceAtMost(8) * 35, easing = FastOutSlowInEasing))
        }
        this.graphicsLayer {
            alpha = a.value
            translationY = (1f - a.value) * 36f
        }
    }
}

suspend fun loadBackground(ctx: Context, uri: String): Bitmap? = withContext(Dispatchers.IO) {
    try {
        val u = Uri.parse(uri)
        val opts = BitmapFactory.Options()
        opts.inJustDecodeBounds = true
        ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, opts) }
        var sample = 1
        while (opts.outWidth / (sample * 2) >= 1080 || opts.outHeight / (sample * 2) >= 1920) sample *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = sample
        ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o2) }
    } catch (_: Throwable) {
        null
    }
}

/** Cheap, version-independent blur: shrink then let the GPU smooth it when scaling back up. */
fun blurBitmap(src: Bitmap, blur: Int): Bitmap {
    if (blur <= 0) return src
    val f = 1 + blur / 6
    val w = (src.width / f).coerceAtLeast(8)
    val h = (src.height / f).coerceAtLeast(8)
    return try {
        Bitmap.createScaledBitmap(src, w, h, true)
    } catch (_: Throwable) {
        src
    }
}

@Composable
fun BlurredBitmap(bitmap: Bitmap, blur: Int, dim: Int) {
    val shown = remember(bitmap, blur) { blurBitmap(bitmap, blur).asImageBitmap() }
    Image(
        bitmap = shown, contentDescription = null, contentScale = ContentScale.Crop,
        modifier = Modifier.fillMaxSize(), filterQuality = FilterQuality.High
    )
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = (dim / 100f).coerceIn(0f, 0.9f))))
}

@Composable
fun BackgroundImage(uri: String, blur: Int, dim: Int) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, uri) {
        value = if (uri.isEmpty()) null else loadBackground(ctx, uri)
    }
    val b = bmp
    if (b != null) BlurredBitmap(b, blur, dim)
}
