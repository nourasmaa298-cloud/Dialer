package app.glassdialer

import android.content.Context
import android.media.AudioManager
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.os.Build
import android.os.Environment
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Best-effort call recording. There is no public Android API that lets a third-party app inject
 * audio into (or guarantee capture of) the other side of a phone call — that capability is
 * deliberately locked down by the platform. This tries the audio sources real recorder apps use,
 * in order of how likely they are to actually capture the call rather than silence, and falls
 * back gracefully if none work. It also plays a short tone on the call's own audio stream as a
 * courtesy "this call is being recorded" cue — audible locally, and to the other party too if the
 * call is on speakerphone — since no app can inject a sound directly into the far end of the line.
 */
object CallRecorder {
    val active = MutableStateFlow(false)
    val seconds = MutableStateFlow(0L)
    val lastFile = MutableStateFlow<String?>(null)
    val lastError = MutableStateFlow<String?>(null)

    private var recorder: MediaRecorder? = null
    private var startMs = 0L
    private var ticker: Thread? = null

    private fun recorderInstance(ctx: Context): MediaRecorder =
        if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else @Suppress("DEPRECATION") MediaRecorder()

    private fun sources(): List<Int> = listOf(
        MediaRecorder.AudioSource.VOICE_CALL,        // needs a system permission most apps don't have; works on some OEM builds
        MediaRecorder.AudioSource.VOICE_COMMUNICATION,
        MediaRecorder.AudioSource.MIC
    )

    fun start(ctx: Context, number: String): Boolean {
        if (active.value) return true
        val dir = File(ctx.getExternalFilesDir(Environment.DIRECTORY_MUSIC), "CallRecordings")
        try {
            if (!dir.exists()) dir.mkdirs()
        } catch (_: Throwable) {
        }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val safeNum = number.filter { it.isDigit() }.ifEmpty { "unknown" }
        val file = File(dir, "call_${safeNum}_$stamp.m4a")

        for (src in sources()) {
            val r = try {
                recorderInstance(ctx)
            } catch (_: Throwable) {
                continue
            }
            try {
                r.setAudioSource(src)
                r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                r.setAudioEncodingBitRate(128_000)
                r.setAudioSamplingRate(44_100)
                r.setOutputFile(file.absolutePath)
                r.prepare()
                r.start()
                recorder = r
                lastFile.value = file.absolutePath
                lastError.value = null
                startMs = System.currentTimeMillis()
                active.value = true
                seconds.value = 0L
                startTicker()
                playNotice(ctx)
                return true
            } catch (_: Throwable) {
                try {
                    r.reset()
                    r.release()
                } catch (_: Throwable) {
                }
            }
        }
        lastError.value = "no_source"
        return false
    }

    fun stop() {
        try {
            recorder?.stop()
        } catch (_: Throwable) {
        }
        try {
            recorder?.release()
        } catch (_: Throwable) {
        }
        recorder = null
        active.value = false
        ticker?.interrupt()
        ticker = null
    }

    private fun startTicker() {
        ticker?.interrupt()
        val t = Thread {
            try {
                while (!Thread.currentThread().isInterrupted && active.value) {
                    seconds.value = (System.currentTimeMillis() - startMs) / 1000
                    Thread.sleep(500)
                }
            } catch (_: InterruptedException) {
            }
        }
        t.isDaemon = true
        ticker = t
        t.start()
    }

    /** A short courtesy tone on the call's own audio stream. */
    private fun playNotice(ctx: Context) {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_VOICE_CALL, 80)
            tg.startTone(ToneGenerator.TONE_PROP_BEEP2, 350)
            Thread({
                try {
                    Thread.sleep(500)
                    tg.release()
                } catch (_: Throwable) {
                }
            }, "cr-tone").start()
        } catch (_: Throwable) {
        }
    }
}
